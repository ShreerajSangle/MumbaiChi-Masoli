import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:mumbaichimasoli/models/user.dart';
import 'package:mumbaichimasoli/config/config.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:mumbaichimasoli/services/database.dart';

class AuthService {
  FirebaseAuth _auth = ConstantVariable.auth;
  String error;

  String getUserId() {
    return _auth.currentUser.uid;
  }

  // create user object based on FirebaseUser
  AppUser _userFromFirebaseUser(User user) {
    return user != null ? AppUser(uid: user.uid) : null;
  }

  // auth change user stream
  Stream<AppUser> get user {
    return _auth.authStateChanges().map(_userFromFirebaseUser);
  }


  // sign up with email and password
  Future register(String fname, String lname, String email, String password) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(email: email, password: password);
      User user = result.user;

      // create a new document for the user with uid
      await DatabaseService(uid: user.uid).updateUserData(fname, lname, email);
      return _userFromFirebaseUser(user);
    } catch (e) {
      error = e.message;
      print(e.toString());
      return null;
    }
  }

  // request an account
  Future request(String fname, String lname, String email) async {
    try{
      await DatabaseService().updateRequestData(fname, lname, email);
    } catch(e){
      print(e.toString());
      error = e.toString();
      return e.toString();
    }
  }

  // sign in with email and password
  Future signInWithEmailAndPassword(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(email: email, password: password);
      User user = result.user;
      return _userFromFirebaseUser(user);
    } catch (e) {
      error = e.message;
      print(e.toString());
      return null;
    }
  }

  // sign out
  Future signOut() async {
    try {
      return await _auth.signOut();

    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  // Reset Password
  Future sendPasswordResetEmail(String email) async {
    error = "A Password reset link has been sent to "+email;
    _auth.sendPasswordResetEmail(email: email);
    return true;
  }

  // check if user is logged in or not
  Future isAvailable() async {
    if (_auth.currentUser != null) {
      return true;
    }
    return false;
  }

  Future returnError() async {
    if(error != null){
      return error;
    }
    return null;
  }
}

class EmailValidator {
  static String validate(String value) {
    if (value.isEmpty) {
      return "         Email can't be empty";
    }
    return null;
  }
}

class PasswordValidator {
  static String validate(String value) {
    if (value.isEmpty) {
      return "         Password can't be empty";
    } 
    if (value.length < 6) {
      return "         Password must have more than 6 characters";
    }
    return null;
  }
}

class FirstNameValidator {
  static String validate(String value) {
    if (value.isEmpty) {
      return "         First Name can't be empty";
    }
    if (value.length < 2) {
      return "         First Name must be at least 2 characters long";
    }
    if (value.length > 50) {
      return "         First Name must be less than 50 characters long";
    }
    return null;
  }
}

class LastNameValidator {
  static String validate(String value) {
    if (value.isEmpty) {
      return "         Last Name can't be empty";
    }
    if (value.length < 2) {
      return "         Last Name must be at least 2 characters long";
    }
    if (value.length > 50) {
      return "         Last Name must be less than 50 characters long";
    }
    return null;
  }
}

class UsernameValidator {
  static String validate(String value) {
    if (value.isEmpty) {
      print("IN USERNAME VALIDATOR");
      return "         Username can't be empty";
    }
    return null;
  }
}

// import 'dart:html';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:mumbaichimasoli/models/user.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:intl/intl.dart';

class DatabaseService {
  final AuthService _auth = AuthService();
  // final AppUser uid_user = AppUser();
  final String uid;
  final String aid;
  final String docid;
  DatabaseService({this.uid, this.aid, this.docid});

  final String CartDetails = "CartDetails";

  final CollectionReference userCollection =
      FirebaseFirestore.instance.collection('users');
  final CollectionReference requestCollection =
      FirebaseFirestore.instance.collection('requests');
  final CollectionReference adminCollection =
      FirebaseFirestore.instance.collection("admin");
  final CollectionReference productsReference =
      FirebaseFirestore.instance.collection('products');

  getDate() {
    DateTime now = DateTime.now();
    String formattedDate = DateFormat('yyyy-MM-dd - kk:mm').format(now);
    return formattedDate;
  }

  Future updateUserData(String fname, String lname, String email) async {
    await userCollection.doc(uid).set({
      'fname': fname,
      'lname': lname,
      'email': email,
      'Address': null,
    });
    return await userCollection
        .doc(_auth.getUserId())
        .collection('CartDetail')
        .doc(CartDetails)
        .set({
      'Total': 0.0,
    });
  }

  updateUserName(String fname, String lname) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(userCollection.doc(_auth.getUserId()),
          {"fname": fname, "lname": lname});
    });
  }

  Future updateRequestData(String fname, String lname, String email) async {
    return await requestCollection.doc().set({
      'fname': fname,
      'lname': lname,
      'email': email,
    });
  }

  // admin password update
  updateAdminPassword(String password) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(
          adminCollection.doc("hZCPSR7OpSrwWqteIjRN"), {"password": password});
    });
  }

  submitFeedback(String feedback, String docid) async {
    return await productsReference
        .doc(docid)
        .collection('Feedback')
        .doc(_auth.getUserId())
        .set({'Feedback': feedback});
  }

  updateAddress(String address) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction
          .update(userCollection.doc(_auth.getUserId()), {'Address': address});
    });
  }

  removeProduct(String docid) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.delete(productsReference.doc(docid));
    });
  }

  checkout(double total) async {
    String checkoutTime = getDate();

    // Place Order
    print('INSIDE PLACEORDER');
    await userCollection
        .doc(_auth.getUserId())
        .collection('Order')
        .doc(checkoutTime)
        .set({
      'Date': DateTime.now(),
      'Total': total,
      'Delivered': false,
      //'Address':address
    });

    // Copy Collection
    print('INSIDE COPYCOLLECTION');
    userCollection
        .doc(_auth.getUserId())
        .collection('Cart')
        .get()
        .then((value) => {
              value.docs.forEach((doc) {
                var promise = userCollection
                    .doc(_auth.getUserId())
                    .collection('Order')
                    .doc(checkoutTime)
                    .collection('Products')
                    .doc(doc.id)
                    .set(doc.data());
              })
            });

    // removeCart
    print('INSIDE REMOVECART');
    userCollection
        .doc(_auth.getUserId())
        .collection('Cart')
        .get()
        .then((snapshot) {
      for (DocumentSnapshot ds in snapshot.docs) {
        ds.reference.delete();
      }
    });
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(
          userCollection
              .doc(_auth.getUserId())
              .collection('CartDetail')
              .doc(CartDetails),
          {"Total": 0.0});
    });
  }

  removeProductFromCart(String docid) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.delete(
          userCollection.doc(_auth.getUserId()).collection('Cart').doc(docid));
    });
  }

  cancelRequest(String docid) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.delete(requestCollection.doc(docid));
    });
  }

  // removeProductFromWhislist(String docid) {
  //   FirebaseFirestore.instance.runTransaction((transaction) async {
  //     transaction.delete(
  //         userCollection.doc(_auth.getUserId()).collection('Whishlist').doc(docid)
  //     );
  //   });
  // }

  getQuantity(docid) async {
    return await userCollection
        .doc(_auth.getUserId())
        .collection('Cart')
        .doc(docid)
        .get()
        .then((document) {
      document.get('Quantity');
    });
  }

  updateCartTotal(double total) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(
          userCollection
              .doc(_auth.getUserId())
              .collection("CartDetail")
              .doc(CartDetails),
          {"Total": total});
    });
  }

  updateProductAmount(String docid, int amount) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(
          userCollection.doc(_auth.getUserId()).collection('Cart').doc(docid),
          {"Amount": amount});
    });
  }

  updateProductQuantity(String docid, int quantity) {
    FirebaseFirestore.instance.runTransaction((transaction) async {
      transaction.update(
          userCollection.doc(_auth.getUserId()).collection('Cart').doc(docid),
          {"Quantity": quantity});
    });
  }
}

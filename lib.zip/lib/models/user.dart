class AppUser {

  final String uid;

  AppUser({ this.uid });

}

class UserData {

  final String uid;
  final String fname;
  final String lname;
  final String email;

  UserData({ this.uid, this.fname, this.lname, this.email });

}
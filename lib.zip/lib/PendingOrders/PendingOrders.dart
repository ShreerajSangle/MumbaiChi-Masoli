import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:mumbaichimasoli/PendingOrders/PendingDetails.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/shared/loading.dart';

class PendingOrd extends StatefulWidget {
  @override
  _PendingOrdState createState() => _PendingOrdState();
}

class _PendingOrdState extends State<PendingOrd> {
  DatabaseService _databaseService = DatabaseService();
  final AuthService _auth = AuthService();

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(80),
          child: AppBar(
              elevation: 0.5,
              title: Padding(
                padding: const EdgeInsets.only(
                    top: 55, left: 24, right: 24.0, bottom: 24.0),
                child: Text(
                  "Pending Orders",
                  style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 24,
                      fontWeight: FontWeight.bold),
                ),
              ),
              backgroundColor: Colors.white),
        ),
        body: FutureBuilder<QuerySnapshot>(
            future: _databaseService.userCollection.get(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Text("Error: ${snapshot.error}"),
                  ),
                );
              }
              if (snapshot.connectionState == ConnectionState.done) {
                //print(snapshot.);
                return ListView(
                    children: snapshot.data.docs.map((user) {
                  print(user.id);
                  return Container(
                      child: FutureBuilder<QuerySnapshot>(
                    future: _databaseService.userCollection
                        .doc(user.id)
                        .collection('Order')
                        .get(),
                    builder: (context, snapshot) {
                      if (snapshot.hasError) {
                        return Scaffold(
                          body: Center(
                            child: Text("Error: ${snapshot.error}"),
                          ),
                        );
                      }
                      if (snapshot.connectionState == ConnectionState.done) {
                        return Column(
                            children: snapshot.data.docs.map((document) {
                          DateTime myDateTime = DateTime.parse(
                              document['Date'].toDate().toString());
                          String formattedDateTime =
                              DateFormat('yyyy-MM-dd – kk:mm')
                                  .format(myDateTime);

                          if (document['Delivered'] == false) {
                            return GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => PendDetails(
                                              userid: user.id,
                                              productid: document.id,
                                            )));
                              },
                              child: Container(
                                margin: EdgeInsets.symmetric(
                                    horizontal:
                                        SizeConfig.blockSizeHorizontal * 3,
                                    vertical: SizeConfig.blockSizeVertical * 2),
                                height: SizeConfig.blockSizeVertical * 15,
                                decoration: BoxDecoration(
                                    color: Colors.red[200],
                                    borderRadius: BorderRadius.circular(10)),
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: SizeConfig.blockSizeHorizontal *
                                              2,
                                          top:
                                              SizeConfig.blockSizeVertical * 2),
                                      child: Row(
                                        children: [
                                          Text(
                                            user['fname'],
                                            style: regtext,
                                          ),
                                          SizedBox(
                                            width:
                                                SizeConfig.blockSizeHorizontal *
                                                    1,
                                          ),
                                          Text(
                                            user['lname'],
                                            style: regtext,
                                          ),
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          top: SizeConfig.blockSizeVertical * 4,
                                          left: SizeConfig.blockSizeHorizontal *
                                              2),
                                      child: Text(user['email']),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: SizeConfig.blockSizeHorizontal *
                                              50,
                                          top: SizeConfig.blockSizeHorizontal *
                                              1),
                                      child: Text("Date:$formattedDateTime"),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          top: SizeConfig.blockSizeVertical *
                                              5.9,
                                          left: SizeConfig.blockSizeHorizontal *
                                              2),
                                      child: Row(
                                        children: [
                                          Text("Total Items:"),
                                          StreamBuilder(
                                            stream: _databaseService
                                                .userCollection
                                                .doc(user.id)
                                                .collection('Order')
                                                .doc(document.id)
                                                .collection('Products')
                                                .snapshots(),
                                            builder: (context, snapshot) {
                                              int _totalItems = 0;
                                              if (snapshot.connectionState ==
                                                  ConnectionState.active) {
                                                List _documents =
                                                    snapshot.data.docs;
                                                _totalItems = _documents.length;
                                              }
                                              return Text("$_totalItems" ?? "0",
                                                  style: TextStyle(
                                                    fontSize: 16.0,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.red,
                                                  ));
                                            },
                                          )
                                        ],
                                      ),
                                    ),
                                    Padding(
                                      padding: EdgeInsets.only(
                                          left: SizeConfig.blockSizeHorizontal *
                                              2,
                                          top: SizeConfig.blockSizeVertical *
                                              12),
                                      child:
                                          Text("Total: ${document["Total"]}"),
                                    )
                                  ],
                                ),
                              ),
                            );
                          }
                          return Container();
                        }).toList());
                      }
                      return Loading();
                    },
                  ));
                }).toList());
              }
              return Loading();
            }));
  }
}

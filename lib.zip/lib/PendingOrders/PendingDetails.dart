import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/shared/loading.dart';

class PendDetails extends StatefulWidget {
  final String userid;
  final String productid;
  PendDetails({this.userid, this.productid});

  @override
  _PendDetailsState createState() => _PendDetailsState();
}

class _PendDetailsState extends State<PendDetails> {
  Size screenSize() {
    return MediaQuery.of(context).size;
  }

  DatabaseService _databaseService = DatabaseService();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(80),
          child: AppBar(
              elevation: 0.5,
              title: Padding(
                padding: const EdgeInsets.only(
                    top: 55, left: 24, right: 24.0, bottom: 24.0),
                child: Text(
                  " Details",
                  style: GoogleFonts.poppins(
                      color: Colors.black,
                      fontSize: 24,
                      fontWeight: FontWeight.bold),
                ),
              ),
              backgroundColor: Colors.white),
        ),
        body: FutureBuilder<QuerySnapshot>(
          future: _databaseService.userCollection
              .doc(widget.userid)
              .collection('Order')
              .doc(widget.productid)
              .collection('Products')
              .get(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Scaffold(
                  body: Center(child: Text("Error: ${snapshot.error}")));
            }
            if (snapshot.connectionState == ConnectionState.done) {
              return Center(
                child: Column(
                    children: snapshot.data.docs.map((product) {
                  return Container(
                    height: SizeConfig.blockSizeVertical * 20,
                    width: screenSize().width,
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(10)),
                    child: Stack(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(
                              top: SizeConfig.blockSizeVertical * 7,
                              left: SizeConfig.safeBlockHorizontal * 2),
                          child: Text(
                            "${product['name']}",
                            style: xlboldhead,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(left: 130),
                          child: Container(
                            margin: EdgeInsets.symmetric(vertical: 10),
                            width: 1,
                            color: Colors.black12,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(
                              left: SizeConfig.safeBlockHorizontal * 50,
                              top: SizeConfig.blockSizeVertical * 6),
                          child: Column(
                            children: [
                              Text(
                                "Price: ${product['price']}",
                                style: regHead,
                              ),
                              Text("Quantity: ${product['Quantity']}kg",
                                  style: regHead),
                              Text("Amount: ${product['Amount']}",
                                  style: regHead),
                            ],
                          ),
                        )
                      ],
                    ),
                  );
                }).toList()),
              );
            }
            return Loading();
          },
        ));
  }
}

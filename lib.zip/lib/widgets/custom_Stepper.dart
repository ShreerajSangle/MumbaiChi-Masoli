import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';

class CustomStepper extends StatefulWidget {
  CustomStepper({
    @required this.lowerLimit,
    @required this.upperLimit,
    @required this.stepValue,
    @required this.iconSize,
    @required this.value,
    @required this.onChanged,
  });

  final int lowerLimit;
  final int upperLimit;
  final int stepValue;
  final double iconSize;
  int value;
  final ValueChanged<dynamic> onChanged;

  @override
  _CustomStepperState createState() => _CustomStepperState();
}

class _CustomStepperState extends State<CustomStepper> {
  @override
  Widget build(BuildContext context) {
    return Container(
      // width: 20,
      // height: 50,
      decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.all(Radius.circular(20))),
      child: Row(
        //mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
              icon: Icon(
                Icons.remove,
                size: SizeConfig.fontSize * 10,
              ),
              onPressed: () {
                setState(() {
                  widget.value = widget.value == widget.lowerLimit
                      ? widget.lowerLimit
                      : widget.value -= widget.stepValue;
                  this.widget.onChanged(widget.value);
                });
              }),
          Container(
            width: SizeConfig.blockSizeHorizontal * 4,
            child: AutoSizeText(
              "${widget.value}",
              maxLines: 1,
              //style: TextStyle(fontSize: widget.iconSize),
              textAlign: TextAlign.center,
            ),
          ),
          IconButton(
              icon: Icon(
                Icons.add,
                size: SizeConfig.fontSize * 12,
              ),
              onPressed: () {
                setState(() {
                  widget.value = widget.value == widget.upperLimit
                      ? widget.upperLimit
                      : widget.value += widget.stepValue;
                  this.widget.onChanged(widget.value);
                });
              }),
          // Align(
          //   alignment: Alignment.topRight,
          //   child: Container(
          //     decoration: BoxDecoration(
          //         color: Colors.blue[100],
          //         borderRadius: BorderRadius.only(
          //             bottomRight: Radius.circular(18),
          //             topRight: Radius.circular(18))),
          //     child: Center(
          //         child: Text(
          //       style: regtext,
          //     )),
          //   ),
          // )
        ],
      ),
    );
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/screen/cartPage.dart';
// import 'package:mumbaichimasoli/services/firebaseServices.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';

class TopBar extends StatelessWidget {
  final bool backArrow;
  final String title;
  final bool hasTitle;
  final bool hasBg;
  final bool hasCart;
  TopBar({this.backArrow, this.title, this.hasTitle, this.hasBg, this.hasCart});

  AuthService _auth = AuthService();
  DatabaseService _databaseService = DatabaseService();
  // FirebaseServices _firebaseServices = FirebaseServices();

  final CollectionReference _users =
      FirebaseFirestore.instance.collection('users');

  @override
  Widget build(BuildContext context) {
    bool _backArrow = backArrow ?? false;
    bool _hasTitle = hasTitle ?? true;
    bool _hasBg = hasBg ?? true;
    bool _hasCart = hasCart ?? true;

    return Container(
      decoration: BoxDecoration(
          gradient: _hasBg
              ? LinearGradient(
                  colors: [Colors.white, Colors.white],
                  begin: Alignment(0, 0),
                  end: Alignment(0, 1),
                )
              : null),
      padding: EdgeInsets.only(top: 26, left: 24, right: 24.0, bottom: 24.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          if (_backArrow)
            GestureDetector(
              onTap: () {
                Navigator.pop(context);
              },
              child: Container(
                child: Icon(
                  Icons.arrow_back_ios,
                  size: 30,
                ),
              ),
            ),
          if (_hasTitle)
            Text(title ?? "TopBar",
                style: GoogleFonts.poppins(
                    fontSize: 24, fontWeight: FontWeight.bold)),
          if (_hasCart)
            GestureDetector(
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => CartPage()));
              },
              child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                      color: Colors.blue,
                      borderRadius: BorderRadius.circular(20)),
                  alignment: Alignment.center,
                  child: StreamBuilder(
                    stream: _databaseService.userCollection
                        .doc(_auth.getUserId())
                        .collection("Cart")
                        .snapshots(),
                    builder: (context, snapshot) {
                      int _totalItems = 0;

                      if (snapshot.connectionState == ConnectionState.active) {
                        List _documents = snapshot.data.docs;
                        _totalItems = _documents.length;
                      }

                      return Text(
                        "$_totalItems" ?? "0",
                        style: TextStyle(
                          fontSize: 16.0,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      );
                    },
                  )),
            )
        ],
      ),
    );
  }
}

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/shared/loading.dart';
import 'package:mumbaichimasoli/widgets/confirmyouradd.dart';
import 'package:provider/provider.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';

class Cartbottom extends StatefulWidget {
  @override
  _CartbottomState createState() => _CartbottomState();
}

class _CartbottomState extends State<Cartbottom> {
  // const Cartbottom({ Key? key }) : su//per(key: key);
  DatabaseService _databaseService = DatabaseService();
  AuthService _auth = AuthService();
  TopBar _topBar = TopBar();

  int total;
  bool isCartEmpty;
  bool cartLength;

  checkCartLength() async {
    // double total;

    _databaseService.userCollection
        .doc(_auth.getUserId())
        .collection('Cart')
        .snapshots()
        .listen((snapshot) {
      cartLength = snapshot.docs.isEmpty;
      // print('cartLength $cartLength');
      return cartLength.toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return Container(
      child: Row(
        children: [
          StreamBuilder(
              stream: _databaseService.userCollection
                  .doc(_auth.getUserId())
                  .collection("CartDetail")
                  .doc("CartDetails")
                  .snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Container(
                    child: Center(
                      child: Text("Error: ${snapshot.error}"),
                    ),
                  );
                }

                if (snapshot.connectionState == ConnectionState.active) {
                  Map _cartMap = snapshot.data.data();

                  // DocumentSnapshot variable =await _databaseService.userCollection.doc('address').get();
                  //_databaseService.userCollection.doc(_auth.getUserId()).get().then(Function(document){print(document["address"])});
                  return Container(
                    child: Row(
                      children: <Widget>[
                        Padding(
                          padding: EdgeInsets.only(left: 20),
                          child: Text(
                            "TOTAL :",
                            style: regHead,
                          ),
                        ),
                        SizedBox(
                          width: 10,
                        ),
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.blue[100],
                              borderRadius: BorderRadius.circular(10)),
                          width: 100,
                          height: 50,
                          child: Center(
                            child: AutoSizeText(
                              // "0",
                              "${_cartMap['Total']}",
                              maxLines: 1,
                              style: regHead,
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 05,
                        ),
                        GestureDetector(
                            onTap: () {
                              checkCartLength();
                              if (!cartLength ?? true) {
                                showDialogBox(context, _cartMap['Total']);
                                // _databaseService.checkout(_cartMap['Total']);
                              }
                              // print('cartlengthfrom on tap $cartLength');
                            },
                            child: Container(
                              height: 50,
                              width: SizeConfig.blockSizeHorizontal * 45,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  color: Colors.red),
                              child: Center(
                                child: Text(
                                  "Checkout",
                                  style: regHead,
                                ),
                              ),
                            ))
                      ],
                    ),
                    height: 60,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        color: Colors.white10),
                    // color: Colors.blue[100],
                  );
                }

                return Loading();
              }),
        ],
      ),
    );
  }
}

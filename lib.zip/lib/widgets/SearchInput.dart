import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';

class SearchInput extends StatelessWidget {
  final String hintText;
  //final Function(String) onChanged;
  final Function(String) onSubmitted;
  final FocusNode focusNode;
  final TextInputAction textInputAction;
  final TextInputType keyboardType;
  //final bool isPasswordField;
  SearchInput(
      {this.hintText, this.onSubmitted, this.focusNode, this.textInputAction, this.keyboardType});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: 8.0,
          horizontal: 24.0,
        ),
        decoration: BoxDecoration(
            color: Colors.blue[100], borderRadius: BorderRadius.circular(12.0)),
        child: TextField(

            // onChanged: onChanged,
            onSubmitted: onSubmitted,
            textInputAction: textInputAction,
            keyboardType: keyboardType,
            decoration: InputDecoration(
                prefixIcon: Icon(Icons.search_rounded),
                border: InputBorder.none,
                hintText: hintText,
                contentPadding: EdgeInsets.symmetric(
                  horizontal: 24.0,
                  vertical: 20.0,
                )),
            style: regHead),
      ),
    );
  }
}

// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/screen/ShippingAdd.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/shared/loading.dart';

void showDialogBox(BuildContext context, double total) {
  final AuthService _auth = AuthService();
  final DatabaseService _databaseService = DatabaseService();

  showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StreamBuilder(
          stream: _databaseService.userCollection
              .doc(_auth.getUserId())
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Scaffold(
                body: Center(
                  child: Text("Error: ${snapshot.error}"),
                ),
              );
            }
            if (snapshot.connectionState == ConnectionState.active) {
              Map _currentuser = snapshot.data.data();
              return AlertDialog(
                  title: Text("Confirm Your Address"),
                  content: Container(
                    height: 100,
                    decoration: BoxDecoration(
                        color: Colors.grey[100],
                        borderRadius: BorderRadius.circular(10)),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 5, vertical: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          Text("${_currentuser['Address']}"),
                        ],
                      ),
                    ),
                  ),
                  actions: <Widget>[
                    TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('Cancel')),
                    TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => ShippingAdd()));
                        },
                        child: Text("Set New Address")),
                    TextButton(
                      child: Text("Confirm"),
                      onPressed: () {
                        _databaseService.checkout(total);
                      },
                    )
                  ]);
            }
            return Loading();
          },
        );
      });
}

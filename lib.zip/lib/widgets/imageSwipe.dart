import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/config/size_config.dart';

class ImageSwipe extends StatefulWidget {
  final List album;
  ImageSwipe({this.album});

  @override
  _ImageSwipeState createState() => _ImageSwipeState();
}

class _ImageSwipeState extends State<ImageSwipe> {
  int _selectedimage = 0;
  @override
  Widget build(BuildContext context) {
    return Container(
      height: SizeConfig.blockSizeVertical * 40,
      child: Stack(
        children: [
          PageView(
            onPageChanged: (num) {
              setState(() {
                _selectedimage = num;
              });
            },
            children: [
              for (var i = 0; i < widget.album.length; i++)
                Container(
                  padding: EdgeInsets.only(top: 80),
                  child: Image.network(
                    "${widget.album[i]}",
                    //fit: BoxFit.cover,
                  ),
                )
            ],
          ),
          Positioned(
            bottom: 10,
            left: 0,
            right: 0,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                for (var i = 0; i < widget.album.length; i++)
                  AnimatedContainer(
                    duration: Duration(milliseconds: 300),
                    curve: Curves.easeInOutCubic,
                    margin: EdgeInsets.symmetric(horizontal: 4.0),
                    width: _selectedimage == i ? 25.0 : 10,
                    height: 10,
                    // color: Colors.indigoAccent,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(10),
                        color: Colors.indigoAccent.withOpacity(0.6)),
                  )
              ],
            ),
          )
        ],
      ),
      // child: Image.network("${documentData['images'][1]}")
    );
  }
}

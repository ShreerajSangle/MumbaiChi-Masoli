import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class BottomTabs extends StatefulWidget {
  final int selectedTab;
  final Function(int) taBPressed;
  BottomTabs({this.selectedTab, this.taBPressed});

  @override
  _BottomTabsState createState() => _BottomTabsState();
}

class _BottomTabsState extends State<BottomTabs> {
  int _selectedTab = 0;

  @override
  Widget build(BuildContext context) {
    _selectedTab = widget.selectedTab ?? 0;

    return Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(12.0),
              topRight: Radius.circular(12.0),
            ),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.06),
                  spreadRadius: 1.0,
                  blurRadius: 22.0)
            ]),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            BottomTabsBtn(
              imagePath: "assets/images/tab_home.png",
              selected: _selectedTab == 0 ? true : false,
              onPressed: () {
                widget.taBPressed(0);
              },
            ),
            BottomTabsBtn(
              imagePath: "assets/images/tab_search.png",
              selected: _selectedTab == 1 ? true : false,
              onPressed: () {
                widget.taBPressed(1);
              },
            ),
            BottomTabsBtn(
              imagePath: "assets/images/tab_saved.png",
              selected: _selectedTab == 2 ? true : false,
              onPressed: () {
                widget.taBPressed(2);
              },
            ),
            BottomTabsBtn(
                imagePath: "assets/images/outline_account.png",
                selected: _selectedTab == 3 ? true : false,
                onPressed: () {
                  widget.taBPressed(3);
                }),
          ],
        ));
  }
}

class BottomTabsBtn extends StatelessWidget {
  final String imagePath;
  final bool selected;
  final Function onPressed;
  BottomTabsBtn({this.imagePath, this.selected, this.onPressed});

  @override
  Widget build(BuildContext context) {
    bool _selected = selected ?? false;

    return GestureDetector(
      onTap: onPressed,
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 24),
        decoration: BoxDecoration(
            border: Border(
                top: BorderSide(
                    color: _selected
                        ? Theme.of(context).accentColor
                        : Colors.transparent,
                    width: 2.0))),
        child: Image(
          image: AssetImage(imagePath ?? "assets/images/tab_home.png"),
          width: 22,
          height: 22,
          color: _selected ? Theme.of(context).accentColor : Colors.black,
        ),
      ),
    );
  }
}

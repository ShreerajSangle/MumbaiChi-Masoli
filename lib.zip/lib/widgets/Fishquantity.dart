import 'package:flutter/material.dart';

class SelQuan extends StatefulWidget {
  final List quantity;
  final Function(int) onSelQuan;

  SelQuan({this.quantity, this.onSelQuan});
  @override
  _SelQuanState createState() => _SelQuanState();
}

class _SelQuanState extends State<SelQuan> {
  int selquantity = 0;
  // getselQuantity() {
  //   return selquantity;
  // }

  @override
  Widget build(BuildContext context) {
    // getselQuantity() {
    //   return selquantity;
    // }

    return Padding(
      padding: const EdgeInsets.only(left: 16.0),
      child: Row(
        children: [
          for (var i = 0; i < widget.quantity.length; i++)
            GestureDetector(
              onTap: () {
                widget.onSelQuan(widget.quantity[i]);
                setState(() {
                  selquantity = i;
                });
              },
              child: Container(
                margin: EdgeInsets.symmetric(horizontal: 6),
                height: 40,
                width: 42,
                decoration: BoxDecoration(
                    color: selquantity == i
                        ? Theme.of(context).accentColor
                        : Color(0xffdcdcdc),
                    borderRadius: BorderRadius.circular(30)),
                alignment: Alignment.center,
                child: Text(
                  '${widget.quantity[i]}',
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      color: selquantity == i ? Colors.white : Colors.blue),
                ),
              ),
            )
        ],
      ),
    );
  }
}

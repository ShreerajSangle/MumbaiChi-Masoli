import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';

class Enterqty extends StatelessWidget {

  
  final quantityController = TextEditingController();

  String returnQuantity () {
    return quantityController.text;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
        width: 110,
        height: 50,
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18), color: Colors.white),
        child: Row(
          children: <Widget>[
            Container(
              height: 40,
              width: 70,
              child: Center(
                  child: TextField(
                    controller: quantityController,
                decoration: InputDecoration(
                    hintText: "Quantity",
                    hintStyle: TextStyle(fontSize: 12),
                    border: InputBorder.none,
                    contentPadding:
                        EdgeInsets.symmetric(horizontal: 12, vertical: 17)),
              )),
              decoration: BoxDecoration(
                  color: Colors.blue[100],
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(11),
                      bottomLeft: Radius.circular(11))),
            ),
            Container(
              height: 40,
              width: 40,
              decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(11),
                      bottomRight: Radius.circular(11))),
              child: Center(
                  child: Text(
                "Kg",
                style: regtext,
              )),
            )
          ],
        ));
  }
}
/*return Padding(
      padding: const EdgeInsets.only(top: 30),
      child: Container(
        margin: EdgeInsets.symmetric(
          vertical: 8.0,
          horizontal: 24.0,
        ),
        decoration: BoxDecoration(
            color: Colors.blue[100], borderRadius: BorderRadius.circular(12.0)),
        child: TextField(

            // onChanged: onChanged,
            onSubmitted: onSubmitted,
            //textInputAction: textInputAction,
            decoration: InputDecoration(
                border: InputBorder.none,
                hintText: "Enter quantity",
                contentPadding: EdgeInsets.symmetric(
                    // horizontal: 24.0,
                    // vertical: 20.0,
                    )),
            style: regHead),
      ),
    );
  }
}*/

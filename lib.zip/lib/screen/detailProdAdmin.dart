import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/imageSwipe.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:fluttertoast/fluttertoast.dart';

class DetailProdAdmin extends StatefulWidget {
  final String productId;
  DetailProdAdmin({this.productId});
  @override
  _DetailProdAdminState createState() => _DetailProdAdminState();
}

class _DetailProdAdminState extends State<DetailProdAdmin> {

  DatabaseService _databaseService = DatabaseService();

  showToast() {
    Fluttertoast.showToast(
      msg: "Data has been Updated",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
    );
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(
      children: <Widget>[
        FutureBuilder(
          future: _databaseService.productsReference.doc(widget.productId).get(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Scaffold(
                body: Center(
                  child: Text("Error:${snapshot.hasError}"),
                ),
              );
            }
            if (snapshot.connectionState == ConnectionState.done) {
              Map<String, dynamic> documentData = snapshot.data.data();

              List album = documentData['images'];
              return ListView(
                padding: EdgeInsets.all(0),
                children: [
                  ImageSwipe(
                    album: album,
                  ),
                  SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 4, horizontal: 24),
                    child: Text(
                      "${documentData['name']}",
                      style: xlboldhead,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 24),
                    child: Text(
                      "₹${documentData['price']}",
                      style: TextStyle(
                          fontSize: 20.0,
                          color: Theme.of(context).accentColor,
                          fontWeight: FontWeight.w700),
                    ),
                  ),
                  Padding(
                    padding:
                        const EdgeInsets.symmetric(vertical: 8, horizontal: 24),
                    child: Text(
                      "${documentData['descr']}",
                      style: TextStyle(fontSize: 16),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(vertical: 0, horizontal: 10),
                    width: SizeConfig.blockSizeHorizontal * 80,
                    child: TextButton(
                      onPressed: () {
                        _databaseService.removeProduct(widget.productId);
                        showToast();
                      },
                      child: Text(
                        "Remove Product",
                        style: regtext,

                      ),
                      style: TextButton.styleFrom(
                          padding: EdgeInsets.all(15),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18)),
                          backgroundColor: Colors.red),
                    ),
                  ),
                ],

              );
            }
            return Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          },
        ),
        TopBar(
          backArrow: true,
          hasTitle: false,
          hasBg: false,
        )
      ],
    ));
  }
}

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:flutter/services.dart';
import 'package:path/path.dart' as Path;
import 'package:image_picker/image_picker.dart';

class Addproduct extends StatefulWidget {
  // List searchString ;

  @override
  _AddproductState createState() => _AddproductState();
}

class _AddproductState extends State<Addproduct> {
  TextEditingController sampledata1 = new TextEditingController();
  TextEditingController sampledata2 = new TextEditingController();
  var sampledata3 = new TextEditingController();

  bool uploading = false;
  double val = 0;
  String value = "";
  String valueChoose1;
  String valueChoose2;
  String valueChoose3;

  List listitem = ["5", "10", "15", "20"];

  CollectionReference imgRef;
  firebase_storage.Reference ref;

  List<File> _image = [];
  List imagelinks = [];
  List quantity = [];
  final picker = ImagePicker();

  // upload file to firestore
  Future uploadFile() async {
    int i = 1;
    for (var img in _image) {
      setState(() {
        val = i / _image.length;
      });
      ref = firebase_storage.FirebaseStorage.instance
          .ref()
          .child('${Path.basename(img.path)}');
      await ref.putFile(img).whenComplete(() async {
        await ref.getDownloadURL().then((value) {
          imagelinks.add(value);
          print("image array1 : $imagelinks");
          i++;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Add Products"),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            children: <Widget>[
              Container(
                color: Colors.lightBlue[50],
                padding: EdgeInsets.all(4.0),
                child: TextFormField(
                  controller: sampledata1,
                  decoration: InputDecoration(
                    hintText: "Name",
                    labelText: "Name",
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                height: 7.0,
              ),
              Container(
                color: Colors.lightBlue[50],
                padding: EdgeInsets.all(4.0),
                child: TextFormField(
                  controller: sampledata2,
                  decoration: InputDecoration(
                    hintText: "Discription",
                    labelText: "Discription",
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              SizedBox(
                height: 7.0,
              ),
              Container(
                color: Colors.lightBlue[50],
                padding: EdgeInsets.all(4.0),
                child: TextFormField(
                  controller: sampledata3,
                  decoration: InputDecoration(
                    hintText: "Price",
                    labelText: "Price",
                    border: OutlineInputBorder(),
                  ),
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly
                  ],
                ),
              ),
              // SizedBox(
              //   height: 7.0,
              // ),
              // Container(
              //   color: Colors.lightBlue[50],
              //   padding: EdgeInsets.all(4.0),
              //   child: TextFormField(
              //     controller: sampledata4,
              //     decoration: InputDecoration(
              //       hintText: "Uniqe string",
              //       labelText: "Search String",
              //       border: OutlineInputBorder(),
              //     ),),
              // ),
              SizedBox(height: 25.0),
              Container(
                color: Colors.cyan[50],
                height: 135.0,
                width: 370.0,
                child: Stack(children: [
                  Container(
                    child: GridView.builder(
                        itemCount: _image.length + 1,
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 3),
                        itemBuilder: (context, index) {
                          return index == 0
                              ? Center(
                                  child: IconButton(
                                      icon: Icon(Icons.add),
                                      alignment: Alignment.centerLeft,
                                      onPressed: () =>
                                          !uploading ? chooseImage() : null),
                                )
                              : Container(
                                  margin: EdgeInsets.all(3),
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                          image: FileImage(_image[index - 1]),
                                          fit: BoxFit.cover)),
                                );
                        }),
                  ),
                  uploading
                      ? Center(
                          child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              child: Text(
                                'uploading...',
                                style: TextStyle(fontSize: 20),
                              ),
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            CircularProgressIndicator(
                              value: val,
                              valueColor:
                                  AlwaysStoppedAnimation<Color>(Colors.green),
                            )
                          ],
                        ))
                      : Container(),
                ]),
              ),
              SizedBox(height: 30.0),
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    DropdownButton(
                        hint: Text("select quantity"),
                        value: valueChoose1,
                        onChanged: (newValue) {
                          setState(() {
                            // quantity[0]=newValue;
                            valueChoose1 = newValue;
                            print(valueChoose1);
                          });
                        },
                        items: listitem.map((valueItem) {
                          return DropdownMenuItem(
                            value: (valueItem),
                            child: Text(valueItem),
                          );
                        }).toList()),
                    DropdownButton(
                        hint: Text("select quantity"),
                        value: valueChoose2,
                        onChanged: (newValue) {
                          setState(() {
                            // quantity[1]=newValue;
                            valueChoose2 = newValue;
                            print(valueChoose2);
                          });
                        },
                        items: listitem.map((valueItem) {
                          return DropdownMenuItem(
                            value: (valueItem),
                            child: Text(valueItem),
                          );
                        }).toList()),
                    DropdownButton(
                        hint: Text("select quantity"),
                        value: valueChoose3,
                        onChanged: (newValue) {
                          setState(() {
                            // quantity[2]=newValue;
                            valueChoose3 = newValue;
                            print(quantity);
                            print(valueChoose3);
                          });
                        },
                        items: listitem.map((valueItem) {
                          return DropdownMenuItem(
                            value: (valueItem),
                            child: Text(valueItem),
                          );
                        }).toList()),
                  ],
                ),
              ),
              SizedBox(height: 80.0),

              Container(
                child: FlatButton(
                  onPressed: () {
                    quantity.add(int.parse(valueChoose1));
                    quantity.add(int.parse(valueChoose2));
                    quantity.add(int.parse(valueChoose3));

                    uploadFile().whenComplete(() {
                      Map<String, dynamic> data = {
                        "name": sampledata1.text,
                        "descr": sampledata2.text,
                        "price": int.parse(sampledata3.text),
                        "searchString": sampledata1.text.toLowerCase(),
                        "images": imagelinks,
                        "quantity": quantity
                      };
                      print("image array : $imagelinks");
                      FirebaseFirestore.instance
                          .collection("products")
                          .add(data);
                      setState(() {
                        uploading = true;
                      });
                      Navigator.of(context).pop();
                    });
                  },
                  child: Text(
                    "submit",
                    style: TextStyle(fontSize: 20),
                  ),
                  textColor: Colors.white,
                  color: Colors.blue[600],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _button(event) => FlatButton(
        child: Text(event),
        onPressed: () async {
          DocumentReference docRef =
              FirebaseFirestore.instance.collection("products").doc('Fish');
          DocumentSnapshot doct = await docRef.get();
          List Quantity = doct['Quantity'];
          if (Quantity.contains(event) == true) {
            docRef.update({
              'tags': FieldValue.arrayRemove([event])
            });
          } else {
            docRef.update({
              'tags': FieldValue.arrayUnion([event])
            });
          }
        },
      );

  // choose image from gallery
  chooseImage() async {
    final pickedFile = await picker.getImage(source: ImageSource.gallery);
    setState(() {
      _image.add(File(pickedFile?.path));
    });
    if (pickedFile.path == null) {
      retrieveLostData();
    }
  }

  Future<void> retrieveLostData() async {
    final LostData response = await picker.getLostData();
    if (response.file != null) {
      setState(() {
        _image.add(File(response.file.path));
      });
    } else {
      print(response.file);
    }
  }

//   @override
//   void initState() {
//     super.initState();
//     // Map <String,dynamic> data1={'images':_image};
//     imgRef = FirebaseFirestore.instance.collection('products');
// }

}

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:email_auth/email_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'admin_changePass.dart';


class VerifyEmailPage extends StatefulWidget {
  @override
  _VerifyEmailPageState createState() => _VerifyEmailPageState();
}

class _VerifyEmailPageState extends State<VerifyEmailPage> {

  String error;
  bool verified = false;

  TextEditingController _emailController = new TextEditingController();
  TextEditingController _otpController = new TextEditingController();

  var _verifyformKey = GlobalKey<FormState>();

  Widget showAlert() {
    if (error != null) {
      return Container(
        color: Colors.amberAccent,
        width: double.infinity,
        padding: EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Icon(Icons.error),
            ),
            Expanded(
              child: AutoSizeText(
                error,
                maxLines: 3,
              )
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  setState(() {
                    error = null;
                  });
                }
              ),
            )
          ],
        ),
      );
    }
    return SizedBox(
      height: 8,
    );
  }

  showToast() {
    Fluttertoast.showToast(
      msg: "OTP has been sent successfully",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
    );
  }

  sendOTP() async {
    EmailAuth.sessionName ="Test Session";
    var response = await EmailAuth.sendOtp(receiverMail: _emailController.text);
    if (response){
      print("OTP Sent");
      showToast();
      return true;
    }else {
      setState(() {
        error = "An error occured. Try again later.";
      });
      print("An error occured. Try again later.");
    }
  }


  verifyOTP() async {
    var response = EmailAuth.validate(receiverMail: _emailController.text, userOTP: _otpController.text);
    if (response){
      print("OTP Verified");
      setState(() {
        verified = true;
      });
    }else {
      setState(() {
        error = "Invalid OTP";
      });
      print("Invalid OTP");
    }
  }

  checkEmail(email) {
    FirebaseFirestore.instance.collection("admin").get().then((snapshot) {
      snapshot.docs.forEach((result) { 
        if(result.data()["email"] != email) {
          setState(() {
            error = "This email is not the registered email";
          });
          return false;
        }else {
          return true;
        }
      });
    });
  }

  static String emailValidate(value) {
    return RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value) ? 
    null : 
    "         Enter a valid Email";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF73AEF5),
                      Color(0xFF61A4F1),
                      Color(0xFF478DE0),
                      Color(0xFF398AE5),
                    ],
                    stops: [0.1, 0.4, 0.7, 0.9],
                  ),
                ),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 110,
                  ),
                  child: Form(
                    key: _verifyformKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(height: 10,),
                        showAlert(),
                        SizedBox(height: 20,),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Verify Email',
                            style: GoogleFonts.openSans(
                              fontSize: 50,
                              color: Colors.white,
                              fontWeight: FontWeight.w600),
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Enter your registered email",
                            style: TextStyle(
                              color: Colors.white60, fontSize: 13),
                          )
                        ),
                        SizedBox(
                          height: 50,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                color: Color(0xFF6CA8F1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 6,
                                    offset: Offset(0, 2)
                                  )
                                ]
                              ),
                              height: 60,
                              child: TextFormField(
                                controller: _emailController,
                                validator: emailValidate,
                                keyboardType: TextInputType.emailAddress,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(top: 14),
                                  prefixIcon:
                                  Icon(Icons.mail, color: Colors.white),
                                  hintText: "Email",
                                  hintStyle:
                                  TextStyle(color: Colors.grey[300]),
                                  suffixIcon: TextButton(
                                    child: Text(
                                      "Send OTP",
                                      style: TextStyle(color: Colors.white),),
                                    onPressed: () {
                                      if(_verifyformKey.currentState.validate()) {
                                        if(error != null) {
                                          return 'ERROR';
                                        }
                                        else if(checkEmail(_emailController.text) == true){
                                          print("checkEmail : "+checkEmail(_emailController.text));
                                          sendOTP();
                                        }
                                      }
                                    },
                                  )
                                ),
                              )
                            )
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                color: Color(0xFF6CA8F1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 6,
                                    offset: Offset(0, 2)
                                  )
                                ]
                              ),
                              height: 60,
                              child: TextFormField(
                                controller: _otpController,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(top: 14),
                                  prefixIcon:
                                  Icon(Icons.lock, color: Colors.white),
                                  hintText: "Enter OTP",
                                  hintStyle:
                                  TextStyle(color: Colors.grey[300]),
                                ),
                              )
                            )
                          ],
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 25),
                          width: double.infinity,
                          child: ElevatedButton(
                            child: Text(
                              'Verify OTP',
                              style: GoogleFonts.openSans(
                                color: Color(0xFF527DAA),
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                            ),
                            onPressed: () {
                              if(_otpController.text.isEmpty){
                                setState( () {
                                  error = "OTP can't be empty";
                                });
                              } else{
                                verifyOTP();
                                if(verified == true) {
                                  Navigator.pushReplacement(
                                    context, 
                                    MaterialPageRoute(builder: (context) => NewPasswordPage())
                                  );
                                }
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(15),
                              primary: Colors.white,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30))
                            ),
                          )
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

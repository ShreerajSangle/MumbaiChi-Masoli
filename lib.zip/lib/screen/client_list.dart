import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/screen/OrderHistory.dart';
import 'package:mumbaichimasoli/screen/clientDetails.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/constants.dart';

class UserList extends StatefulWidget {
  @override
  _UserListState createState() => _UserListState();
}

class _UserListState extends State<UserList> {
  DatabaseService _databaseService = DatabaseService();
  final AuthService _auth = AuthService();

  //final CollectionReference _clientReference = FirebaseFirestore.instance.collection("user");
  @override
  Widget build(BuildContext context) {
    Size screenSize() {
      return MediaQuery.of(context).size;
    }

    SizeConfig().init(context);
    return Scaffold(
      appBar: AppBar(
        title: Text('User list'),
        centerTitle: true,
      ),
      body: Stack(children: <Widget>[
        FutureBuilder<QuerySnapshot>(
            future: _databaseService.userCollection.get(),
            // ignore: missing_return
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Text("Error : ${snapshot.error}"),
                  ),
                );
              }
              if (snapshot.hasData && snapshot.data != null) {
                if (snapshot.connectionState == ConnectionState.done) {
                  return ListView(
                      children: snapshot.data.docs.map((document) {
                    return GestureDetector(
                      onTap: () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Clientdetail()));
                      },
                      child: Container(
                        margin: EdgeInsets.symmetric(
                            horizontal: SizeConfig.blockSizeHorizontal * 2,
                            vertical: SizeConfig.blockSizeHorizontal * 2),
                        decoration: BoxDecoration(
                            color: Colors.blue[100],
                            borderRadius: BorderRadius.circular(10)),

                        height: SizeConfig.blockSizeHorizontal * 35,
                        width: screenSize().width,
                        // color: Colors.blue,
                        child: Stack(
                          children: [
                            Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: EdgeInsets.only(
                                        left:
                                            SizeConfig.blockSizeHorizontal * 5,
                                        top:
                                            SizeConfig.blockSizeVertical * 3.5),
                                    child: Row(
                                        //   mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(
                                            "Name:",
                                            style: regHead,
                                          ),
                                          Text(
                                            "${document["fname"]}",
                                            style: regtext,
                                          ),
                                          SizedBox(width: 5),
                                          Text(
                                            "${document["lname"]}",
                                            style: regtext,
                                          )
                                        ]),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  //  Text("${document["fname"]}"),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 18.0),
                                    child: Container(
                                      child: Row(
                                        children: [
                                          Text("Email:", style: regHead),
                                          Container(
                                              // width: 300,
                                              child: AutoSizeText(
                                            "${document["email"]}",
                                            maxLines: 1,
                                            style: regtext,
                                          )),
                                        ],
                                      ),
                                    ),
                                  ),

                                  Padding(
                                    padding: EdgeInsets.only(
                                        left: SizeConfig.blockSizeHorizontal *
                                            70),
                                    child: ElevatedButton(
                                        onPressed: () {
                                          Navigator.push(
                                              context,
                                              MaterialPageRoute(
                                                  builder: (context) =>
                                                      YourOrders(
                                                          userId:
                                                              document.id)));
                                        },
                                        child: Text("Orders")),
                                  )
                                ]),
                          ],
                        ),
                      ),
                    );
                  }).toList());
                }
              }
              return Container(
                child: Center(child: CircularProgressIndicator()),
              );
            })
      ]),
    );
  }
}

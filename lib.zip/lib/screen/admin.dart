// import 'package:admin_home_side/dashboard_screens/categories.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/dashboard_screen/categories.dart';
import 'package:mumbaichimasoli/dashboard_screen/users.dart';
// import 'package:admin_home_side/dashboard_screens/users.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/PendingOrders/PendingOrders.dart';
import 'package:mumbaichimasoli/screen/SignIn.dart';
import 'package:mumbaichimasoli/screen/SignUp.dart';
import 'package:mumbaichimasoli/screen/addproduct.dart';
import 'package:mumbaichimasoli/screen/product_list.dart';
import 'package:mumbaichimasoli/screen/req_accounts.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import '../db/category.dart';
import '../db/brand.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'client_list.dart';
// import 'package:cupertino_icons/cupertino_icons.dart';

enum Page { dashboard, manage }

class Admin extends StatefulWidget {
  @override
  _AdminState createState() => _AdminState();
}

class _AdminState extends State<Admin> {
  Size screenSize() {
    return MediaQuery.of(context).size;
  }

  final AuthService _auth = AuthService();
  Page _selectedPage = Page.dashboard;
  //MaterialColor active = Colors.white;
  //MaterialColor notActive = Colors.black;
  TextEditingController categoryController = TextEditingController();
  TextEditingController brandController = TextEditingController();
  GlobalKey<FormState> _categoryFormKey = GlobalKey();
  GlobalKey<FormState> _brandFormKey = GlobalKey();
  BrandService _brandService = BrandService();
  CategoryService _categoryService = CategoryService();

  Widget build(BuildContext context) {
    var active;
    var notActive;
    return Scaffold(
        appBar: AppBar(
          title: Row(
            children: <Widget>[
              Expanded(
                  child: FlatButton.icon(
                      onPressed: () {
                        setState(() => _selectedPage = Page.dashboard);
                      },
                      icon: Icon(
                        Icons.dashboard,
                        color: _selectedPage == Page.dashboard
                            ? active = Colors.white
                            : notActive,
                      ),
                      label: Text('Dashboard'))),
              Expanded(
                  child: FlatButton.icon(
                      onPressed: () {
                        setState(() => _selectedPage = Page.manage);
                      },
                      icon: Icon(
                        Icons.sort,
                        color: _selectedPage == Page.manage
                            ? active = Colors.white
                            : notActive,
                      ),
                      label: Text('Manage'))),
            ],
          ),
          elevation: 0.0,
          backgroundColor: Colors.blueAccent,
        ),
        body: _loadScreen());
  }

  Widget _loadScreen() {
    switch (_selectedPage) {
      case Page.dashboard:
        return SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ListTile(
                subtitle: FlatButton.icon(
                  onPressed: () {},
                  icon: Icon(
                    Icons.person,
                    size: 30.0,
                    color: Colors.blueAccent,
                  ),
                  label: Text('ADMIN',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 30.0, color: Colors.blueAccent)),
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => UserList()));
                },
                child: Container(
                  margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(vertical: 19),
                    child: Column(
                      children: [
                        Text("CLIENTS", style: regHead),
                        Icon(Icons.people_outlined, size: 100),
                      ],
                    ),
                  ),
                  decoration: BoxDecoration(
                      color: Colors.blue[100],
                      borderRadius: BorderRadius.circular(18)),
                  height: 160,
                  width: screenSize().width,
                ),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => Requsetedaccount()));
                },
                child: Container(
                    margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    height: 160,
                    width: screenSize().width,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 19),
                      child: Column(
                        children: [
                          Text(
                            "Requested Account",
                            style: regHead,
                          ),
                          Icon(
                            Icons.announcement_outlined,
                            size: 100,
                          )
                        ],
                      ),
                    )),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => ProductList()));
                },
                child: Container(
                    margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    height: 160,
                    width: screenSize().width,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 19),
                      child: Column(
                        children: [
                          Text(
                            "Products",
                            style: regHead,
                          ),
                          Icon(
                            Icons.track_changes,
                            size: 100,
                          )
                        ],
                      ),
                    )),
              ),
              GestureDetector(
                onTap: () {
                  Navigator.push(context,
                      MaterialPageRoute(builder: (context) => PendingOrd()));
                },
                child: Container(
                    margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    height: 160,
                    width: screenSize().width,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 19),
                      child: Column(
                        children: [
                          Text(
                            "Pending Orders",
                            style: regHead,
                          ),
                          Icon(
                            Icons.watch,
                            size: 100,
                          )
                        ],
                      ),
                    )),
              ),
            ],
          ),
        );
        break;
      case Page.manage:
        return ListView(
          children: <Widget>[
            Divider(),
            ListTile(
                leading: Icon(Icons.add),
                title: Text("Add Product"),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Addproduct(),
                      ));
                }),
            Divider(),
            ListTile(
              leading: Icon(Icons.people_outline),
              title: Text("Add users"),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Signup(),
                  ),
                );
              },
            ),
            Divider(),
            ListTile(
                leading: Icon(Icons.account_circle),
                title: Text("Requested accounts"),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Requsetedaccount(),
                      ));
                }),
            Divider(),
            ListTile(
              leading: Icon(Icons.library_books),
              title: Text("Users list"),
              onTap: () {
                // navigateToUserPage(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => UserList(),
                    ));
              },
            ),
            Divider(),
            ListTile(
              leading: Icon(Icons.logout),
              title: Text("Logout"),
              onTap: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => SignIn(),
                    ));
              },
            )
          ],
        );
        break;
      default:
        return Container();
    }
  }

  void _categoryAlert() {
    var alert = new AlertDialog(
      content: Form(
        key: _categoryFormKey,
        child: TextFormField(
          controller: categoryController,
          validator: (value) {
            if (value.isEmpty) {
              return 'category cannot be empty';
            }
          },
          decoration: InputDecoration(hintText: "add category"),
        ),
      ),
      actions: <Widget>[
        FlatButton(
            onPressed: () {
              if (categoryController.text != () {}) {
                _categoryService.createCategory(categoryController.text);
              }
              Fluttertoast.showToast(msg: 'category created');
              Navigator.pop(context);
            },
            child: Text('ADD')),
        FlatButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('CANCEL')),
      ],
    );

    showDialog(context: context, builder: (_) => alert);
  }

  void _brandAlert() {
    var alert = new AlertDialog(
      content: Form(
        key: _brandFormKey,
        child: TextFormField(
          controller: brandController,
          validator: (value) {
            if (value.isEmpty) {
              return 'category cannot be empty';
            }
          },
          decoration: InputDecoration(hintText: "add brand"),
        ),
      ),
      actions: <Widget>[
        FlatButton(
            onPressed: () {
              if (brandController.text != () {}) {
                _brandService.createBrand(brandController.text);
              }
              Fluttertoast.showToast(msg: 'brand added');
              Navigator.pop(context);
            },
            child: Text('ADD')),
        FlatButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('CANCEL')),
      ],
    );

    showDialog(context: context, builder: (_) => alert);
  }

  Future navigateToUserPage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => Users()));
  }

  Future navigateToAdminPage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => Admin()));
  }

  Future navigateToCategoryListPage(context) async {
    Navigator.push(
        context, MaterialPageRoute(builder: (context) => CategoryList()));
  }
}

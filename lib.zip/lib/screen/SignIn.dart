import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/screen/Register_screen.dart';
import 'package:mumbaichimasoli/screen/admin_login.dart';
import 'package:mumbaichimasoli/screen/home_page.dart';
import 'package:mumbaichimasoli/screen/reset_password.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/shared/loading.dart';
import '../constants.dart';

class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {

  void _togglePasswordView() {
    setState(() {
      isHiddenPassword = !isHiddenPassword;
    });
  }

  bool isHiddenPassword = true;
  bool loading = false;
  String signinEmail;
  String signinPass;
  String error;

  final AuthService _auth = AuthService();
  var _signinformKey = GlobalKey<FormState>();

  TextEditingController signInEmailcon = new TextEditingController();
  TextEditingController signInPasscon = new TextEditingController();


  Widget showAlert() {
    if (error != null) {
      print("inside if statement");
      return Container(
        color: Colors.amberAccent,
        width: double.infinity,
        padding: EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Icon(Icons.error),
            ),
            Expanded(
              child: AutoSizeText(
                error,
                maxLines: 3,
              )
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  setState(() {
                    error = null;
                  });
                }
              ),
            )
          ],
        ),
      );
    }
    return SizedBox(height: 8,);
  }

  @override
  Widget build(BuildContext context) {
    return loading ? Loading() : /*new WillPopScope(
      onWillPop: () async => false,
      child: */
      Scaffold(
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.light,
          sized: false,
          child: GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Stack(
              children: <Widget>[
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF73AEF5),
                        Color(0xFF61A4F1),
                        Color(0xFF478DE0),
                        Color(0xFF398AE5),
                      ],
                      stops: [0.1, 0.4, 0.7, 0.9],
                    ),
                  ),
                  child: SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(),
                    padding: EdgeInsets.symmetric(
                      horizontal: 40,
                      vertical: 110,
                    ),
                    child: Form(
                      key: _signinformKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(
                            height: 10,
                          ),
                          showAlert(),
                          SizedBox(height: 20),
                          Align(
                            alignment: Alignment.topLeft,
                            child: Text(
                              'Sign In',
                              style: GoogleFonts.openSans(
                                fontSize: 50,
                                color: Colors.white,
                                fontWeight: FontWeight.w600
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 50,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                alignment: Alignment.centerLeft,
                                decoration: BoxDecoration(
                                  color: Color(0xFF6CA8F1),
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 6,
                                      offset: Offset(0, 2)
                                    )
                                  ]
                                ),
                                height: 60,
                                child: TextFormField(
                                  controller: signInEmailcon,
                                  validator: EmailValidator.validate,
                                  keyboardType:
                                      TextInputType.emailAddress,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.only(top: 14),
                                    prefixIcon: Icon(
                                      Icons.mail,
                                      color: Colors.white
                                    ),
                                    hintText: "Email",
                                    hintStyle: kHintTextStyle
                                  ),
                                )
                              )
                            ],
                          ),
                          SizedBox(
                            height: 30,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                alignment: Alignment.centerLeft,
                                decoration: BoxDecoration(
                                  color: Color(0xFF6CA8F1),
                                  borderRadius:
                                      BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 6,
                                      offset: Offset(0, 2)
                                    )
                                  ]
                                ),
                                height: 60,
                                child: TextFormField(
                                  controller: signInPasscon,
                                  obscureText: isHiddenPassword,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    contentPadding:
                                        EdgeInsets.only(top: 14),
                                    prefixIcon: Icon(Icons.lock,
                                        color: Colors.white),
                                    hintText: "Password",
                                    hintStyle: kHintTextStyle,
                                    suffixIcon: InkWell(
                                      onTap: _togglePasswordView,
                                      child: Icon(
                                        isHiddenPassword ? Icons.visibility : Icons.visibility_off,
                                        color: Colors.white,
                                      ),
                                    )
                                  ),
                                )
                              )
                            ],
                          ),
                          SizedBox(
                            height: 12,
                          ),
                          Container(
                            alignment: Alignment.centerRight,
                            child: TextButton(
                              onPressed: () => Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => ResetPass())
                              ),
                              child: Text(
                                "Forgot Password?",
                                style: kLabelStyle,
                              ),
                              style: TextButton.styleFrom(
                                padding: EdgeInsets.only(right: 0)
                              )
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(vertical: 25),
                            width: double.infinity,
                            child: ElevatedButton(
                              child: Text(
                                'LOGIN',
                                style: GoogleFonts.openSans(
                                  color: Color(0xFF527DAA),
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                  letterSpacing: 1.5,
                                ),
                              ),
                              onPressed: () async {
                                if (_signinformKey.currentState.validate()) {
                                  setState(() {
                                    signinEmail = signInEmailcon.text;
                                    signinPass = signInPasscon.text;
                                    loading = true;
                                    print('SignInEmail: $signinEmail');
                                    print('SignInPass: $signinPass');
                                  });
                                  dynamic result = await _auth.signInWithEmailAndPassword(signinEmail, signinPass);
                                  if (result != null) {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (context) => HomePage()),
                                    );

                                  } else {
                                    result = await _auth.returnError();
                                    setState(() {
                                      error = result;
                                      loading = false;
                                    });
                                    print('error: ' + error);
                                  }
                                }
                              },
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.all(15),
                                primary: Colors.white,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)
                                )
                              ),
                            )
                          ),
                          GestureDetector(
                            onTap: () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(builder: (context) => Register())
                              );
                            }, 
                            child: RichText(
                              text: TextSpan(children: [
                              TextSpan(
                                text: 'Don\'t have an Account?',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 15,
                                  fontWeight: FontWeight.w500,
                                )
                              ),
                              TextSpan(
                                text: ' Request Account',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500
                                )
                              )
                            ])),
                          ),
                          SizedBox(height: 240,),
                          Container(
                            child: Row(
                              children: [
                                Icon(
                                  Icons.admin_panel_settings,
                                  color: Colors.white,
                                ),
                                GestureDetector(
                                  onTap: () {
                                    Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(builder: (context) => AdminLoginScreen())
                                    );
                                  },
                                  child: Text(
                                    'I am Admin',
                                    style: kLabelStyle,
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    // );
  }
}

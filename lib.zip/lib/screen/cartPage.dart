import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
// import 'package:mumbaichimasoli/services/firebaseServices.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/shared/loading.dart';
import 'package:mumbaichimasoli/widgets/cartbottom.dart';
import 'package:mumbaichimasoli/widgets/enterqty.dart';
import 'package:mumbaichimasoli/widgets/SearchInput.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:mumbaichimasoli/widgets/custom_Stepper.dart';
import 'package:provider/provider.dart';
import '../constants.dart';
import 'package:mumbaichimasoli/screen/detailProdAdmin.dart';

class CartPage extends StatefulWidget {
  @override
  _CartPageState createState() => _CartPageState();
}

class _CartPageState extends State<CartPage> {
  AuthService _auth = AuthService();
  DatabaseService _databaseService = DatabaseService();

  bool loading = false;
  int _quantity = 10;
  int amount = 0;
  // dynamic total = 10;

  calculateAmount(String docid, int quantity, int price) async {
    amount = quantity * price;
    await _databaseService.updateProductAmount(docid, amount);
    calculateTotal();
  }

  calculateTotal() async {
    // double total;
    double temp;
    _databaseService.userCollection
        .doc(_auth.getUserId())
        .collection('Cart')
        .snapshots()
        .listen((snapshot) {
      temp = snapshot.docs.fold(0, (tot, doc) => tot + doc['Amount']);
      // print('temp $temp');
      _databaseService.updateCartTotal(temp);
    });
  }

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    // int total = 0;

    Size screenSize() {
      return MediaQuery.of(context).size;
    }

    return Scaffold(
        body: Stack(
      children: [
        StreamBuilder(
          stream: _databaseService.userCollection
              .doc(_auth.getUserId())
              .collection("Cart")
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.hasError) {
              return Scaffold(
                body: Center(
                  child: Text("Error: ${snapshot.error}"),
                ),
              );
            }

            if (snapshot.connectionState == ConnectionState.active) {
              return ListView(
                padding: EdgeInsets.only(top: 90.0, bottom: 80.0),
                children: snapshot.data.docs.map<Widget>((document) {
                  calculateTotal();
                  return GestureDetector(
                      // onTap: () {
                      //   Navigator.push(
                      //       context,
                      //       MaterialPageRoute(
                      //           builder: (context) => DetailProd(
                      //                 productId: document.id,
                      //               )));
                      // },
                      child: StreamBuilder(
                          stream: _databaseService.productsReference
                              .doc(document.id)
                              .snapshots(),
                          builder: (context, productSnap) {
                            if (productSnap.hasError) {
                              return Container(
                                child: Center(
                                  child: Text("${productSnap.error}"),
                                ),
                              );
                            }
                            if (productSnap.connectionState ==
                                ConnectionState.active) {
                              Map _productMap = productSnap.data.data();

                              return Stack(
                                children: [
                                  SingleChildScrollView(
                                    child: Container(
                                      width:
                                          SizeConfig.blockSizeHorizontal * 250,
                                      height:
                                          SizeConfig.blockSizeVertical * 17.7,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(10),
                                        color: Colors.white,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.grey,
                                            offset: Offset(0.0, 1.0), //(x,y)
                                            blurRadius: 2.0,
                                          ),
                                        ],
                                      ),
                                      // margin: EdgeInsets.symmetric(
                                      //   horizontal: 10, vertical: 6),
                                      child: Padding(
                                        padding: EdgeInsets.symmetric(
                                          vertical:
                                              SizeConfig.blockSizeVertical *
                                                  2.0,
                                          horizontal:
                                              SizeConfig.blockSizeHorizontal *
                                                  3.0,
                                        ),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceEvenly,
                                          children: [
                                            Container(
                                              width: SizeConfig
                                                      .blockSizeHorizontal *
                                                  25,
                                              height:
                                                  SizeConfig.blockSizeVertical *
                                                      12,
                                              child: ClipRRect(
                                                borderRadius:
                                                    BorderRadius.circular(8.0),
                                                child: Image.network(
                                                  "${_productMap['images'][0]}",
                                                  fit: BoxFit.cover,
                                                  height: SizeConfig
                                                          .blockSizeVertical *
                                                      50,
                                                  width: SizeConfig
                                                          .blockSizeHorizontal *
                                                      20,
                                                ),
                                              ),
                                            ),
                                            Expanded(
                                              child: Container(
                                                padding: EdgeInsets.only(
                                                    left: SizeConfig
                                                            .blockSizeHorizontal *
                                                        5
                                                    // right: 10.0,
                                                    ),
                                                height: SizeConfig
                                                        .blockSizeVertical *
                                                    15,
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: <Widget>[
                                                        Container(
                                                            height: SizeConfig
                                                                    .blockSizeHorizontal *
                                                                9,
                                                            width: SizeConfig
                                                                    .blockSizeVertical *
                                                                10,
                                                            // color: Colors.blue,
                                                            child: AutoSizeText(
                                                              "${_productMap['name']}",
                                                              maxLines: 1,
                                                              style: TextStyle(
                                                                  fontWeight:
                                                                      FontWeight
                                                                          .bold),
                                                            )),
                                                        Padding(
                                                          padding: EdgeInsets.only(
                                                              left: SizeConfig
                                                                      .blockSizeHorizontal *
                                                                  9),
                                                          child: CustomStepper(
                                                              lowerLimit: 1,
                                                              upperLimit: 100,
                                                              stepValue: 1,
                                                              iconSize: 18,
                                                              value: document[
                                                                  'Quantity'],
                                                              onChanged:
                                                                  (value) {
                                                                _databaseService
                                                                    .updateProductQuantity(
                                                                        document
                                                                            .id,
                                                                        value);
                                                                calculateAmount(
                                                                    document.id,
                                                                    value,
                                                                    _productMap[
                                                                        'price']);

                                                                // setState(() {
                                                                //   total = total + document['Amount'];
                                                                // });

                                                                // print(value);
                                                                print(
                                                                    "Amount: ${document['Amount']}");
                                                              }),
                                                        ),
                                                        Container(
                                                          height: SizeConfig
                                                                  .blockSizeVertical *
                                                              6,
                                                          width: SizeConfig
                                                                  .blockSizeHorizontal *
                                                              4,
                                                          // color: Colors.red,
                                                          alignment: Alignment
                                                              .topRight,
                                                          child: Text(
                                                            "kg",
                                                            style: TextStyle(
                                                                fontSize: SizeConfig
                                                                        .fontSize *
                                                                    13,
                                                                color:
                                                                    Colors.blue,
                                                                fontWeight:
                                                                    FontWeight
                                                                        .w600),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                    SizedBox(
                                                      height: 11,
                                                    ),
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "Price:",
                                                          style: TextStyle(
                                                            fontSize: SizeConfig
                                                                    .fontSize *
                                                                14.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        Text(
                                                          "\₹${_productMap['price']}",
                                                          style: TextStyle(
                                                              fontSize: 14.0,
                                                              color: Theme.of(
                                                                      context)
                                                                  .accentColor,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600),
                                                        ),
                                                      ],
                                                    ),
                                                    Row(
                                                      children: [
                                                        Text(
                                                          "Amount:",
                                                          style: TextStyle(
                                                            fontSize: SizeConfig
                                                                    .fontSize *
                                                                14.0,
                                                            fontWeight:
                                                                FontWeight.w600,
                                                          ),
                                                        ),
                                                        SizedBox(
                                                          width: 10,
                                                        ),
                                                        Container(
                                                            height: SizeConfig
                                                                    .blockSizeVertical *
                                                                3,
                                                            width: SizeConfig
                                                                    .blockSizeHorizontal *
                                                                20,
                                                            // color: Colors.blue,
                                                            child: Align(
                                                              alignment: Alignment
                                                                  .centerLeft,
                                                              child:
                                                                  AutoSizeText(
                                                                "\₹${document['Amount']}",
                                                                maxLines: 1,
                                                                style: TextStyle(
                                                                    fontSize:
                                                                        14.0,
                                                                    color: Theme.of(
                                                                            context)
                                                                        .accentColor,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w600),
                                                              ),
                                                            )),
                                                        Padding(
                                                          padding: EdgeInsets.only(
                                                              left: SizeConfig
                                                                      .blockSizeHorizontal *
                                                                  20),
                                                          child:
                                                              GestureDetector(
                                                            onTap: () async {
                                                              await _databaseService
                                                                  .removeProductFromCart(
                                                                      document
                                                                          .id);
                                                              calculateTotal();
                                                            },
                                                            child: Icon(Icons
                                                                .delete_forever_outlined),
                                                          ),
                                                        )
                                                      ],
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            }
                            return Container(
                              child: Center(
                                child: CircularProgressIndicator(),
                              ),
                            );
                          }));
                }).toList(),
              );
            }

            return Scaffold(
              body: Center(
                child: CircularProgressIndicator(),
              ),
            );
          },
        ),
        TopBar(
          title: "Cart",
          backArrow: true,
          hasCart: false,
        ),
        Align(alignment: Alignment.bottomCenter, child: Cartbottom())
      ],
    ));
  }
}

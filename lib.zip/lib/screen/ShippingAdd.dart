import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';

class ShippingAdd extends StatelessWidget {
  String shippingAdd;

  TextEditingController address = new TextEditingController();
  TextEditingController pincode = new TextEditingController();
  TextEditingController city = new TextEditingController();
  TextEditingController state = new TextEditingController();

  DatabaseService _databaseService = DatabaseService();

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);

    return Scaffold(
        body: SingleChildScrollView(
      child: Column(
        children: [
          TopBar(
            title: "Shipping Address",
            hasCart: false,
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
            child: Column(
              children: [
                Center(
                    child: Container(
                  height: 100,
                  decoration: BoxDecoration(
                      color: Colors.blue[100],
                      borderRadius: BorderRadius.circular(18)),
                  width: SizeConfig.blockSizeHorizontal * 80,
                  child: TextField(
                    controller: address,
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    decoration: InputDecoration(
                        border: InputBorder.none,
                        hintText: "Address",
                        prefixIcon: Icon(
                          Icons.landscape,
                        )),
                    obscureText: false,
                    // keyboardType: TextInputType.text,
                  ),
                )),
                SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    width: SizeConfig.blockSizeHorizontal * 80,
                    child: Center(
                      child: TextField(
                        controller: pincode,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "Pincode",
                            prefixIcon: Icon(Icons.location_city)),
                        obscureText: false,
                        keyboardType: TextInputType.number,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    width: SizeConfig.blockSizeHorizontal * 80,
                    child: Center(
                      child: TextField(
                        controller: city,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "City",
                            prefixIcon: Icon(Icons.location_city)),
                        obscureText: false,
                        keyboardType: TextInputType.text,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Center(
                  child: Container(
                    decoration: BoxDecoration(
                        color: Colors.blue[100],
                        borderRadius: BorderRadius.circular(18)),
                    width: SizeConfig.blockSizeHorizontal * 80,
                    child: Center(
                      child: TextField(
                        controller: state,
                        decoration: InputDecoration(
                            border: InputBorder.none,
                            hintText: "State",
                            prefixIcon: Icon(Icons.map)),
                        obscureText: false,
                        keyboardType: TextInputType.text,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 50,
                ),
                Container(
                  width: SizeConfig.blockSizeHorizontal * 80,
                  child: TextButton(
                    onPressed: () {
                      shippingAdd = (address.text + ", " +
                          pincode.text + ", " +
                          city.text + ", " +
                          state.text);
                      print(shippingAdd);
                      _databaseService.updateAddress(shippingAdd);
                      Navigator.pop(context);
                    },
                    child: Text(
                      "Submit",
                      style: regtext,
                    ),
                    style: TextButton.styleFrom(
                        padding: EdgeInsets.all(15),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18)),
                        backgroundColor: Colors.blue[50]),
                  ),
                ),
                SizedBox(
                  height: 10,

                ),

                Container(
                  width: SizeConfig.blockSizeHorizontal * 80,
                  child: TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: Text(
                      "Cancel",
                      style: regtext,
                    ),
                    style: TextButton.styleFrom(
                        padding: EdgeInsets.all(15),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(18)),
                        backgroundColor: Colors.blue[50]),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    ));
  }
}

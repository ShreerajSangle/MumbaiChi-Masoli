import 'package:mumbaichimasoli/screen/SignIn.dart';
import 'package:mumbaichimasoli/screen/home_page.dart';
import 'package:flutter/material.dart';
// import 'package:mumbaichimasoli/screen/splash_screen.dart';
import 'package:provider/provider.dart';
import 'package:mumbaichimasoli/models/user.dart';

class Wrapper extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    
    final user = Provider.of<AppUser>(context);
    // print("uid");
    // print(user.uid);
    // print(user.toString());

    // return either home or signin widget
    if(user == null) {
      return SignIn();
    } else {
      return HomePage();
    }

  }
}




// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/Fishquantity.dart';
// import 'package:mumbaichimasoli/widgets/custom_Stepper.dart';
import 'package:mumbaichimasoli/widgets/imageSwipe.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/imageSwipe.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:fluttertoast/fluttertoast.dart';

class DetailProd extends StatefulWidget {
  final String productId;
  DetailProd({this.productId});
  @override
  _DetailProdState createState() => _DetailProdState();
}

class _DetailProdState extends State<DetailProd> {
  TextEditingController feedback = new TextEditingController();
  AuthService _auth = AuthService();
  DatabaseService _databaseService = DatabaseService();
  // SelQuan _selQuan = SelQuan();
  // FirebaseServices _firebaseServices = FirebaseServices();

  int _selQuantity = 0;
  int index = 0;
  int amount = 0;

  calculateAmount(String docid, int quantity, int price) {
    int result = quantity * price;
    setState(() {
      amount = result;
    });
  }

  Future _add2Cart(String name, int price) {
    return _databaseService.userCollection
        .doc(_auth.getUserId())
        .collection("Cart")
        .doc(widget.productId)
        .set({
      "Quantity": _selQuantity,
      "Amount": amount,
      "id": widget.productId,
      "name": name,
      "price": price,
    });
  }

  Future _add2wishlist() {
    return _databaseService.userCollection
        .doc(_auth.getUserId())
        .collection("Wishlist")
        .doc(widget.productId)
        .set({
      "Quantity": _selQuantity,
    });
  }

  final SnackBar _add2cartmsg = SnackBar(
      duration: const Duration(seconds: 02),

      // padding: EdgeInsets.only(bottom: 24),
      backgroundColor: Colors.green,
      content: Text("Fish added to cart ",
          style: GoogleFonts.openSans(
              fontWeight: FontWeight.w600, color: Colors.white)));

  final SnackBar _add2wishlistmsg = SnackBar(
      duration: const Duration(seconds: 2),
      backgroundColor: Colors.green,
      content: Text(
        "Fish added to wishlist",
        style: GoogleFonts.openSans(
            fontWeight: FontWeight.w600, color: Colors.white),
      ));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: <Widget>[
            FutureBuilder(
              future: _databaseService.productsReference
                  .doc(widget.productId)
                  .get(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Scaffold(
                    body: Center(
                      child: Text("Error:${snapshot.hasError}"),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.done) {
                  Map<String, dynamic> documentData = snapshot.data.data();

                  List album = documentData['images'];
                  // List quantiy = documentData['quantity'];
                  List quantiy = snapshot.data['quantity'];

                  // _selQuantity = quantiy[index];
                  return Expanded(
                    child: ListView(
                      padding: EdgeInsets.all(0),
                      children: [
                        ImageSwipe(
                          album: album,
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 4, horizontal: 24),
                          child: Text(
                            "${documentData['name']}",
                            style: xlboldhead,
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 24),
                          child: Text(
                            "₹${documentData['price']}",
                            style: TextStyle(
                                fontSize: 30.0,
                                color: Theme.of(context).accentColor,
                                fontWeight: FontWeight.w700),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 8, horizontal: 24),
                          child: Text(
                            "${documentData['descr']}",
                            style: TextStyle(fontSize: 16),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              vertical: 25, horizontal: 24),
                          child: Text(
                            "Select Quantity",
                            style: regtext,
                          ),
                        ),
                        SelQuan(
                          quantity: quantiy,
                          onSelQuan: (quantiy) {
                            _selQuantity = quantiy;
                            calculateAmount(widget.productId, _selQuantity,
                                documentData['price']);
                          },
                        ),
                        Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 24, vertical: 20),
                            child: Container(
                              height: 96,
                              decoration: BoxDecoration(
                                  color: Colors.grey[100],
                                  borderRadius: BorderRadius.circular(18)),
                              child: Column(
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 10, right: 10),
                                    child: TextField(
                                      controller: feedback,
                                      decoration: InputDecoration(
                                          hintText: "Provide Feedback",
                                          border: InputBorder.none),
                                    ),
                                  ),
                                  Align(
                                    alignment: Alignment.bottomRight,
                                    child: TextButton(
                                        onPressed: () {
                                          _databaseService.submitFeedback(
                                              feedback.text, widget.productId);
                                        },
                                        child: Text("Submit")),
                                  )
                                ],
                              ),
                            )),
                        Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 16.0, vertical: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            children: <Widget>[
                              ElevatedButton(
                                onPressed: () async {
                                  await _add2wishlist();
                                  ScaffoldMessenger.of(context)
                                      .showSnackBar(_add2wishlistmsg);
                                },
                                child: Row(
                                  children: [
                                    Image.asset(
                                      "assets/images/tab_saved.png",
                                      height: 22,
                                    ),
                                    SizedBox(
                                      width: 5,
                                    ),
                                    Text(
                                      "Wishlist",
                                      style: TextStyle(
                                          fontSize: 15,
                                          fontWeight: FontWeight.w500,
                                          color: Colors.black),
                                    )
                                  ],
                                ),
                                style: ElevatedButton.styleFrom(
                                    padding: EdgeInsets.all(15),
                                    primary: Colors.grey[300],
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10))),
                              ),
                              SizedBox(
                                width: 13,
                              ),
                              Expanded(
                                child: ElevatedButton(
                                  onPressed: () async {
                                    await _add2Cart(documentData['name'],
                                        documentData['price']);
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(_add2cartmsg);
                                  },
                                  child: Row(
                                    children: [
                                      Icon(Icons.shopping_cart),
                                      /*    Image.asset(
                                                "assets/images2/add2_cart.png",
                                                height: 25,
                                              ),*/
                                      SizedBox(
                                        width: 10,
                                      ),
                                      Text(
                                        "Add to cart",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.white),
                                      )
                                    ],
                                  ),
                                  style: ElevatedButton.styleFrom(
                                      padding: EdgeInsets.all(15),
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(10))),
                                ),
                              ),
                              SizedBox(
                                width: 5,
                              ),
                            ],
                          ),
                        )
                      ],
                    ),
                  );
                }
                return Scaffold(
                  body: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              },
            ),
            TopBar(
              backArrow: true,
              hasTitle: false,
              hasBg: false,
            )
          ],
        ));
  }
}

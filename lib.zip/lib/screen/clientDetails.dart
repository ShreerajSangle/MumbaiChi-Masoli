import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';

class Clientdetail extends StatelessWidget {
  final AuthService _auth = AuthService();
  final CollectionReference userCollection =
      FirebaseFirestore.instance.collection('users');
  final DatabaseService _databaseService = DatabaseService();
  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
            elevation: 0.5,
            title: Padding(
              padding: const EdgeInsets.only(
                  top: 55, left: 24, right: 24.0, bottom: 24.0),
              child: Text(
                "Details",
                style: GoogleFonts.poppins(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
            ),
            backgroundColor: Colors.white),
      ),
      body: Stack(
        children: [
          StreamBuilder(
              stream: userCollection.doc(_auth.getUserId()).snapshots(),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return Scaffold(
                    body: Center(
                      child: Text("Error: ${snapshot.error}"),
                    ),
                  );
                }
                if (snapshot.connectionState == ConnectionState.active) {
                  Map _info = snapshot.data.data();
                  return Container(
                    child: Column(
                      children: [
                        Row(children: [
                          Text("{")
                        ],)
                      ],
                    ),
                  );
                }
                return Text("wowwwww");
              })
        ],
      ),
    );
  }
}

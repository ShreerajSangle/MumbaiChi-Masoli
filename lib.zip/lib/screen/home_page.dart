import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/tabs/HomeTab.dart';
import 'package:mumbaichimasoli/tabs/ProfileTab.dart';
import 'package:mumbaichimasoli/tabs/SavedTab.dart';
import 'package:mumbaichimasoli/tabs/SearchTab.dart';
import 'package:mumbaichimasoli/widgets/bottomTabs.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  PageController _bottmtbsPageController;
  int _selectedTb = 0;

  @override
  void initState() {
    _bottmtbsPageController = PageController();
    super.initState();
  }

  @override
  void dispose() {
    _bottmtbsPageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
            child: PageView(
              controller: _bottmtbsPageController,
              onPageChanged: (num) {
                setState(() {
                  _selectedTb = num;
                });
              },
              children: <Widget>[
                HomeTb(),
                SearchTb(),
                SavedTb(),
                ProfileTb(),
              ],
            ),
          ),
          BottomTabs(
            selectedTab: _selectedTb,
            taBPressed: (num) {
              _bottmtbsPageController.animateToPage(num,
                  duration: Duration(milliseconds: 400),
                  curve: Curves.easeOutCubic);
            },
          )
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:auto_size_text/auto_size_text.dart';
import 'package:mumbaichimasoli/screen/admin_login.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';

class NewPasswordPage extends StatefulWidget {
  @override
  _NewPasswordPageState createState() => _NewPasswordPageState();
}

class _NewPasswordPageState extends State<NewPasswordPage> {
  
  void _togglePasswordView() {
    setState(() {
      isHiddenPassword = !isHiddenPassword;
    });
  }

  void _toggleConfirmPasswordView() {
    setState(() {
      isHiddenConfirmPassword = !isHiddenConfirmPassword;
    });
  }

  var _changePassformKey = GlobalKey<FormState>();

  bool isHiddenPassword = true;
  bool isHiddenConfirmPassword = true;
  String newPass;
  String confirmPass;
  String error;

  TextEditingController newPasswordcon = new TextEditingController();
  TextEditingController confirmPasscon = new TextEditingController();

  confirmPassword() {
    if(newPass == confirmPass) {
      return null;
    } else {
      setState(() {
        error = "Password doesn't match";
      });
    }
  }
  
  Widget showAlert() {
    if (error != null) {
      return Container(
        color: Colors.amberAccent,
        width: double.infinity,
        padding: EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Icon(Icons.error),
            ),
            Expanded(
              child: AutoSizeText(
                error,
                maxLines: 3,
              )
            ),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  setState(() {
                    error = null;
                  });
                }
              ),
            )
          ],
        ),
      );
    }
    return SizedBox(
      height: 8,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle.light,
        child: GestureDetector(
          onTap: () => FocusScope.of(context).unfocus(),
          child: Stack(
            children: <Widget>[
              Container(
                height: double.infinity,
                width: double.infinity,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF73AEF5),
                      Color(0xFF61A4F1),
                      Color(0xFF478DE0),
                      Color(0xFF398AE5),
                    ],
                    stops: [0.1, 0.4, 0.7, 0.9],
                  ),
                ),
                child: SingleChildScrollView(
                  physics: AlwaysScrollableScrollPhysics(),
                  padding: EdgeInsets.symmetric(
                    horizontal: 40,
                    vertical: 110,
                  ),
                  child: Form(
                    key: _changePassformKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        SizedBox(height: 10,),
                        showAlert(),
                        SizedBox(height: 20,),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            'Change Password',
                            style: GoogleFonts.openSans(
                              fontSize: 50,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 50,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[                           
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                color: Color(0xFF6CA8F1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 6,
                                    offset: Offset(0, 2)
                                  )
                                ]
                              ),
                              height: 60,
                              child: TextFormField(
                                validator: PasswordValidator.validate,
                                controller: newPasswordcon,
                                obscureText: isHiddenPassword,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(top: 14),
                                  prefixIcon: Icon(Icons.lock, color: Colors.white),
                                  hintText: "New Password",
                                  hintStyle:
                                  TextStyle(color: Colors.grey[300]),
                                  suffixIcon: InkWell(
                                    onTap: _togglePasswordView,
                                    child: Icon(
                                      isHiddenPassword ? Icons.visibility : Icons.visibility_off,
                                      color: Colors.white,
                                    ),
                                  )
                                ),
                              )
                            )
                          ],
                        ),
                        SizedBox(
                          height: 30,
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                              alignment: Alignment.centerLeft,
                              decoration: BoxDecoration(
                                color: Color(0xFF6CA8F1),
                                borderRadius: BorderRadius.circular(10),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    blurRadius: 6,
                                    offset: Offset(0, 2),
                                  )
                                ]
                              ),
                              height: 60,
                              child: TextFormField(
                                validator: confirmPassword(),
                                controller: confirmPasscon,
                                obscureText: isHiddenConfirmPassword,
                                style: TextStyle(
                                  color: Colors.white,
                                ),
                                decoration: InputDecoration(
                                  border: InputBorder.none,
                                  contentPadding: EdgeInsets.only(top: 14),
                                  prefixIcon: Icon(Icons.lock, color: Colors.white),
                                  hintText: "Confirm Password",
                                  hintStyle:
                                  TextStyle(color: Colors.grey[300]),
                                  suffixIcon: InkWell(
                                    onTap: _toggleConfirmPasswordView,
                                    child: Icon(
                                      isHiddenConfirmPassword ? Icons.visibility : Icons.visibility_off,
                                      color: Colors.white,
                                    ),
                                  )
                                ),
                              )
                            )
                          ],
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 25),
                          width: double.infinity,
                          child: ElevatedButton(
                            child: Text(
                              'Update Password',
                              style: GoogleFonts.openSans(
                                color: Color(0xFF527DAA),
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                letterSpacing: 1.5,
                              ),
                            ),
                            onPressed: () async {
                              setState(() {
                                newPass = newPasswordcon.text;
                                confirmPass = confirmPasscon.text;
                              });
                              if(confirmPassword() == null) {
                                print("inside confirm password loop");
                                dynamic result = await DatabaseService().updateAdminPassword(newPass);
                                if(result == null){
                                  print("Password successfully change");
                                  Navigator.of(context).pop();
                                }
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.all(15),
                              primary: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(30)
                              )
                            ),
                          )
                        ),
                      ],
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    ); 
  }
}

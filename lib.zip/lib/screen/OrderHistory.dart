import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:mumbaichimasoli/PendingOrders/PendingDetails.dart';
import 'package:mumbaichimasoli/config/size_config.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';

class YourOrders extends StatefulWidget {
  final String userId;
  YourOrders({this.userId});
  @override
  _YourOrdersState createState() => _YourOrdersState();
}

class _YourOrdersState extends State<YourOrders> {
  final AuthService _auth = AuthService();

  final DatabaseService _databaseService = DatabaseService();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
            elevation: 0.5,
            title: Padding(
              padding: const EdgeInsets.only(
                  top: 55, left: 24, right: 24.0, bottom: 24.0),
              child: Text(
                "Orders History",
                style: GoogleFonts.poppins(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
            ),
            backgroundColor: Colors.white),
      ),
      body: FutureBuilder<QuerySnapshot>(
        future: _databaseService.userCollection
            .doc(widget.userId)
            .collection('Order')
            .get(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Scaffold(
              body: Center(
                child: Text("Error: ${snapshot.error}"),
              ),
            );
          }

          if (snapshot.connectionState == ConnectionState.done) {
            return ListView(
                padding:
                    EdgeInsets.only(bottom: SizeConfig.blockSizeVertical * 10),
                children: snapshot.data.docs.map((document) {
                  DateTime myDateTime =
                      DateTime.parse(document['Date'].toDate().toString());
                  String formattedDateTime =
                      DateFormat('yyyy-MM-dd – kk:mm').format(myDateTime);

                  final sregHead = TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: document['Delivered'] ? Colors.green : Colors.red);

                  return GestureDetector(
                    onTap: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => PendDetails(
                                    userid: _auth.getUserId(),
                                    productid: document.id,
                                  )));
                    },
                    child: Padding(
                        padding: EdgeInsets.only(
                            top: SizeConfig.blockSizeVertical * 1,
                            left: SizeConfig.blockSizeHorizontal * 5,
                            right: SizeConfig.blockSizeHorizontal * 5),
                        child: Container(
                          height: SizeConfig.blockSizeVertical * 13,
                          decoration: BoxDecoration(
                              color: Colors.grey[200],
                              borderRadius: BorderRadius.circular(15)),
                          child: Stack(
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    top: SizeConfig.blockSizeVertical * 3,
                                    left: SizeConfig.blockSizeHorizontal * 3),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text('Date: $formattedDateTime'),
                                    Row(
                                      children: [
                                        Text("Total Items:"),
                                        StreamBuilder(
                                          stream: _databaseService
                                              .userCollection
                                              .doc(widget.userId)
                                              .collection('Order')
                                              .doc(document.id)
                                              .collection('Products')
                                              .snapshots(),
                                          builder: (context, snapshot) {
                                            int _totalItems = 0;
                                            if (snapshot.connectionState ==
                                                ConnectionState.active) {
                                              List _documents =
                                                  snapshot.data.docs;
                                              _totalItems = _documents.length;
                                            }
                                            return Text("$_totalItems" ?? "0",
                                                style: TextStyle(
                                                  fontSize: 16.0,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.blue,
                                                ));
                                          },
                                        )
                                      ],
                                    ),
                                    Text(
                                      "Total: ${document["Total"]}",
                                    ),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    left: SizeConfig.blockSizeHorizontal * 50,
                                    top: SizeConfig.blockSizeVertical * 1),
                                child: Row(
                                  children: [
                                    Text("Status:"),
                                    SizedBox(
                                      width: SizeConfig.blockSizeHorizontal * 3,
                                    ),
                                    document['Delivered']
                                        ? Text("Delivered ", style: sregHead)
                                        : Text("Pending ", style: sregHead),
                                  ],
                                ),
                              )
                            ],
                          ),
                        )),
                  );
                }).toList());
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }
}

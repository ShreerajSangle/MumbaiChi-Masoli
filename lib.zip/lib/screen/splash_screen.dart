// import 'dart:async';
import 'package:flutter/material.dart';
// import 'package:mumbaichimasoli/config/config.dart';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
// import 'package:mumbaichimasoli/screen/SignIn.dart';
// import 'package:mumbaichimasoli/screen/home_page.dart';
import 'package:mumbaichimasoli/screen/wrapper.dart';
import 'package:splashscreen/splashscreen.dart';


class SplashScreenWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return SplashScreen(
      seconds: 4,
      navigateAfterSeconds: Wrapper(),
      title: Text(
        'मुंबईची मासोळी',
        style: TextStyle(
          color: Colors.blue,
          fontSize: 35,
          fontWeight: FontWeight.bold
        ),
      ),
      image: Image.asset(
        'assets/images2/masoli.png',
      ),
      photoSize: 100.0,
      loaderColor: Colors.blue,
    );
  }
}
// class SplashScreen extends StatefulWidget {
//   @override
//   _SplashScreenState createState() => _SplashScreenState();
// }

// class _SplashScreenState extends State<SplashScreen> {
//   @override
//   void initState() {
//     super.initState();
//     displaySplash();
//   }

//   displaySplash() {
//     Timer(Duration(seconds: 5), () {
//       if (ConstantVariable.auth.currentUser != null) {
//         Route route = MaterialPageRoute(builder: (_) => HomePage());
//         Navigator.pushReplacement(context, route);
//       }
//       else {
//         Route route = MaterialPageRoute(builder: (_) => SignIn());
//         Navigator.pushReplacement(context, route);
//       } 
//     });
//   }

//   @override
//   Widget build(BuildContext context) {
//     return GestureDetector(
//       onTap: () => Navigator.push(
//         context,
//         MaterialPageRoute(
//           builder: (builder) => SignIn(),
//         )
//       ),
//       child: Scaffold(
//         body: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           crossAxisAlignment: CrossAxisAlignment.center,
//           children: <Widget>[
//             Padding(
//               padding: EdgeInsets.only(top: 24),
//               child: Center(
//                 child: Text(
//                   'मुंबईची मासोळी',
//                   style: TextStyle(
//                     color: Colors.blue,
//                     fontSize: 50,
//                     fontWeight: FontWeight.bold
//                   ),
//                 ),
//               ),
//             ),
//             Image.asset(
//               'assets/images2/masoli.png',
//               height: 400.0,
//             ),
//             SizedBox(
//               height: 30.0,
//             ),
//             SpinKitRipple(color: Colors.red),
//           ],
//         ),
//       ),
//     );
//   }
// }


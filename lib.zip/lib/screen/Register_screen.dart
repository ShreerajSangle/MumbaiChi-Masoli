import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/screen/SignIn.dart';
import 'package:mumbaichimasoli/services/auth.dart';

class Register extends StatefulWidget {
  @override
  _RegisterState createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  String requestAccEmail;
  String requestfname;
  String requestlname;

  TextEditingController requestAccCon = new TextEditingController();
  TextEditingController fnamecon = new TextEditingController();
  TextEditingController lnamecon = new TextEditingController();

  final AuthService _auth = AuthService();
  var _registerformKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return /*new WillPopScope(
      onWillPop: () async => false,
      child: */
      Scaffold(
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.light,
          child: GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Stack(
              children: <Widget>[
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Color(0xFF73AEF5),
                        Color(0xFF61A4F1),
                        Color(0xFF478DE0),
                        Color(0xFF398AE5),
                      ],
                      stops: [0.1, 0.4, 0.7, 0.9],
                    ),
                  ),
                  child: SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(),
                    padding: EdgeInsets.symmetric(
                      horizontal: 35,
                      vertical: 110,
                    ),
                    child: Form(
                      key: _registerformKey,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(
                            'Request Account',
                            style: GoogleFonts.openSans(
                              fontSize: 50,
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          SizedBox(
                            height: 40,
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              /*Text(
                              'First Name',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                                ),*/
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                alignment: Alignment.centerLeft,
                                decoration: BoxDecoration(
                                  color: Color(0xFF6CA8F1),
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 6,
                                      offset: Offset(0, 2)
                                    )
                                  ]
                                ),
                                height: 60,
                                child: TextFormField(
                                  //  textCapitalization:
                                  //    TextCapitalization.sentences,
                                  controller: fnamecon,
                                  validator: FirstNameValidator.validate,
                                  keyboardType: TextInputType.name,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                    border: InputBorder.none,
                                    contentPadding: EdgeInsets.only(top: 14),
                                    prefixIcon: Icon(Icons.account_circle, color: Colors.white),
                                    hintText: "First Name",
                                    hintStyle: kHintTextStyle,
                                  ),
                                )
                              )
                            ],
                          ),
                          SizedBox(height: 0),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              /* Text(
                              'Last Name',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 20,
                                fontWeight: FontWeight.bold),
                              ),*/
                              SizedBox(height: 10,),
                              Container(
                                alignment: Alignment.centerLeft,
                                decoration: BoxDecoration(
                                  color: Color(0xFF6CA8F1),
                                  borderRadius: BorderRadius.circular(10),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black12,
                                      blurRadius: 6,
                                      offset: Offset(0, 2),
                                    )
                                  ]
                                ),
                                height: 60,
                                child: TextFormField(
                                  controller: lnamecon,
                                  validator: LastNameValidator.validate,
                                  keyboardType: TextInputType.name,
                                  style: TextStyle(
                                    color: Colors.white,
                                  ),
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      contentPadding:
                                          EdgeInsets.only(top: 14),
                                      prefixIcon: Icon(Icons.account_circle,
                                          color: Colors.white),
                                      hintText: "Last name",
                                      hintStyle: kHintTextStyle),
                                ))
                            ],
                          ),
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                  alignment: Alignment.centerLeft,
                                  decoration: BoxDecoration(
                                      color: Color(0xFF6CA8F1),
                                      borderRadius: BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                            color: Colors.black12,
                                            blurRadius: 6,
                                            offset: Offset(0, 2))
                                      ]),
                                  height: 60,
                                  child: TextFormField(
                                    controller: requestAccCon,
                                    validator: EmailValidator.validate,
                                    keyboardType: TextInputType.emailAddress,
                                    style: TextStyle(
                                      color: Colors.white,
                                    ),
                                    decoration: InputDecoration(
                                        errorStyle: TextStyle(
                                          fontWeight: FontWeight.w400,
                                        ),
                                        border: InputBorder.none,
                                        contentPadding:
                                            EdgeInsets.only(top: 14),
                                        prefixIcon: Icon(Icons.mail,
                                            color: Colors.white),
                                        hintText: "Email",
                                        hintStyle: kHintTextStyle),
                                  ))
                            ],
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Container(
                              alignment: Alignment.center,
                              child: GestureDetector(
                                onTap: () {
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => SignIn()));
                                },
                                child: Text(
                                  "Already have an account? Sign in",
                                  style: TextStyle(color: Colors.white),
                                ),
                              )),
                          SizedBox(
                            height: 12,
                          ),
                          Container(
                              padding: EdgeInsets.symmetric(vertical: 25),
                              width: double.infinity,
                              child: ElevatedButton(
                                child: Text(
                                  'REQUEST',
                                  style: GoogleFonts.openSans(
                                      color: Color(0xFF527DAA),
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5),
                                ),
                                onPressed: () async {
                                  if (_registerformKey.currentState.validate()) {
                                    setState(() {
                                      requestAccEmail = requestAccCon.text;
                                      requestfname = fnamecon.text;
                                      requestlname = lnamecon.text;
                                    });
                                    // print("request Pressed");
                                    print('ReqEmail :$requestAccEmail');
                                    print('Reqfname :$requestfname');
                                    print('ReqEmail :$requestlname');
                                    dynamic result = await _auth.request(requestfname, requestlname, requestAccEmail);
                                    if(result != null){
                                      print("error occur during requesting account");
                                    } else {
                                      Route route = MaterialPageRoute(builder: (c) => SignIn());
                                      Navigator.pushReplacement(context, route);
                                      print("Request has been registered.");
                                    }
                                  }
                                },
                                style: ElevatedButton.styleFrom(
                                    padding: EdgeInsets.all(15),
                                    primary: Colors.white,
                                    shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(25))),
                              ))
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
    // );
  }
}

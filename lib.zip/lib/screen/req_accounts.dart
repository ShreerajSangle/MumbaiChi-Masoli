

import 'package:auto_size_text/auto_size_text.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:fluttertoast/fluttertoast.dart';


class Requsetedaccount extends StatefulWidget {


  @override
  _State createState() => _State();
}

class _State extends State<Requsetedaccount> {
  DatabaseService _databaseService = DatabaseService();
  AuthService _auth = AuthService();

  final String DefaultPass = "pass123";

  showToast() {
    Fluttertoast.showToast(
      msg: "Data has been Updated",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.CENTER,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Requested Accounts"),
      ),
 //backgroundColor:Color(0xFF73AEF5),
      body: Stack(
          children: <Widget>[
            FutureBuilder<QuerySnapshot>(
                future: _databaseService.requestCollection.get(),
                // ignore: missing_return
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Scaffold(
                     
                      body: Center(
                        child: Text("Error : ${snapshot.error}"),
                      ),
                    );
                  }
                  if(!snapshot.hasData){
                    return Center(
                      child: Container(child: Text("No requested Accounts"),),
                    );
                  }
                  else if (snapshot.connectionState == ConnectionState.done) {
                    return ListView(
                                        padding: EdgeInsets.only(top: 50.0, bottom: 80.0),
                        children: snapshot.data.docs.map((document) {
                          return Padding(
                                          padding: EdgeInsets.symmetric(vertical:10,horizontal: 10),
                            child: Container(
                            //  height: 10,
                              decoration: BoxDecoration(
                                color:Colors.blue,
                                borderRadius: BorderRadius.circular(11)
                              ),
                              child: Stack(
                                children: [
                                  Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children:[
                                      Padding(
                                        padding: const EdgeInsets.symmetric(vertical:15,horizontal: 18),
                                        child: Row(
                                       //   mainAxisAlignment: MainAxisAlignment.center,
                                          children:[
                                          
                                          Text("${document["fname"]}",style:  TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),),
                                          SizedBox(width:10),
                                          Text("${document["lname"]}",style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),)


                                          ]
                                        ),
                                      ),
                                      
                                    //  Text("${document["fname"]}"),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal:18.0),
                                        child: Row(
                                          
                                          children: [
                                            Text("${document["email"]}",style:  TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white),),
                                          ],
                                        ),
                                      )
                                    ]
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal:15,vertical:15),
                                    child: Align(
                                      alignment: Alignment.topRight,
                                                                        child: Column(
                                       children: [
                                         IconButton(
                                           onPressed: () {
                                             _databaseService.cancelRequest(document.id);
                                             showToast();
                                           },
                                           icon: const Icon(Icons.delete),
                                           color: Colors.white,
                                         ),
                                         SizedBox(
                                           height:25
                                         ),
                                         Container(
                                           height: 20,
                                           width: 90,
                                         //  margin: const EdgeInsets. all(10.0),
//padding: const EdgeInsets. all(3.0),
                                            decoration: BoxDecoration(
                                              
                                        borderRadius: BorderRadius.circular(5),
                                        color: Colors.blue,
                                        boxShadow: [
                                          BoxShadow(
                                            color: Colors.black,
                                            offset: Offset(0.0, 1.0), //(x,y)
                                            blurRadius: 1.0,
                                          ),
                                        ],
                                      ),
                                           child: GestureDetector(
                                             onTap: () {
                                                _auth.register(document['fname'], document['lname'], document['email'], DefaultPass);
                                                _databaseService.cancelRequest(document.id);
                                                showToast();
                                             },
                                             child: AutoSizeText(
                                               "Set Password",style: TextStyle(color:Colors.white), maxLines: 1,),
                                           ),
                                         )
                                       ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                            ),
                          );


                        }).toList()
                    );
                  }
                }
            ),

          ]
          
      ),
    );
  }
}


import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/constants.dart';
// import 'package:mumbaichimasoli/screen/SignIn.dart';
import 'package:mumbaichimasoli/services/auth.dart';

class ResetPass extends StatefulWidget {
  @override
  _ResetPassState createState() => _ResetPassState();
}

class _ResetPassState extends State<ResetPass> {

  String email;

  var _forgetformKey = GlobalKey<FormState>();

  final AuthService _auth = AuthService();
  TextEditingController forgetPassEmailcon = new TextEditingController();

  @override
  Widget build(BuildContext context) {
    return /*new WillPopScope(
      onWillPop: () async => false,
      child: */
      Scaffold(
        body: AnnotatedRegion<SystemUiOverlayStyle>(
          value: SystemUiOverlayStyle.light,
          child: GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            child: Stack(
              children: <Widget>[
                Container(
                  height: double.infinity,
                  width: double.infinity,
                  decoration: BoxDecoration(
                      gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Color(0xFF73AEF5),
                      Color(0xFF61A4F1),
                      Color(0xFF478DE0),
                      Color(0xFF398AE5),
                    ],
                    stops: [0.1, 0.4, 0.7, 0.9],
                  )),
                ),
                Container(
                  height: double.infinity,
                  child: SingleChildScrollView(
                    physics: AlwaysScrollableScrollPhysics(),
                    padding: EdgeInsets.symmetric(horizontal: 20, vertical: 90),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: <Widget>[
                        Text(
                          "Forgot Password, Don't Worry",
                          style: GoogleFonts.openSans(
                            fontSize: 35,
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Align(
                          alignment: Alignment.topLeft,
                          child: Text(
                            "Just Enter your email below",
                            style: TextStyle(
                              color: Colors.white60, fontSize: 13,
                            ),
                          )
                        ),
                        SizedBox(
                          height: 20,
                        ),
                        Form(
                          key: _forgetformKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                  alignment: Alignment.centerLeft,
                                  decoration: BoxDecoration(
                                      color: Color(0xFF6CA8F1),
                                      borderRadius: BorderRadius.circular(10),
                                      boxShadow: [
                                        BoxShadow(
                                            color: Colors.black12,
                                            blurRadius: 6,
                                            offset: Offset(0, 2))
                                      ]),
                                  height: 60,
                                  child: TextFormField(
                                    controller: forgetPassEmailcon,
                                    validator: EmailValidator.validate,
                                    keyboardType: TextInputType.emailAddress,
                                    style: TextStyle(
                                      color: Colors.white,
                                    ),
                                    decoration: InputDecoration(
                                        border: InputBorder.none,
                                        contentPadding:
                                            EdgeInsets.only(top: 14),
                                        prefixIcon: Icon(Icons.mail,
                                            color: Colors.white),
                                        hintText: "Email",
                                        hintStyle: kHintTextStyle),
                                  ))
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 25),
                          width: double.infinity,
                          child: ElevatedButton(
                            child: Text(
                              "Reset Password",
                              style: GoogleFonts.openSans(
                                color: Color(0xFF527DAA),
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.all(15),
                                primary: Colors.white,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(30))),
                            onPressed: () {
                              if(_forgetformKey.currentState.validate()){
                                setState(() {
                                  email = forgetPassEmailcon.text;
                                });
                                _auth.sendPasswordResetEmail(email);
                                Navigator.of(context).pop();
                              } 
                            } 
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    // );
  }
}

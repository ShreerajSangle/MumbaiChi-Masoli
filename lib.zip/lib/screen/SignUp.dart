import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/screen/SignIn.dart';
import 'package:mumbaichimasoli/services/auth.dart';

class Signup extends StatefulWidget {
  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  final AuthService _auth = AuthService();
  bool isHiddenPassword = true;
  var _signupformKey = GlobalKey<FormState>();

  void _togglePasswordView() {
    setState(() {
      isHiddenPassword = !isHiddenPassword;
    });
  }

  String signupEmail;
  String signupPass;
  String confirmPass;
  String firstName;
  String lastName;
  String error = "";

  TextEditingController signUpEmailcon = new TextEditingController();
  TextEditingController signUpPasscon = new TextEditingController();
  TextEditingController confirmPasscon = new TextEditingController();
  TextEditingController namecon = new TextEditingController();
  TextEditingController lastnamecon = new TextEditingController();

  Widget showAlert() {
    if (error != null) {
      return Container(
        color: Colors.amberAccent,
        width: double.infinity,
        padding: EdgeInsets.all(8.0),
        child: Row(
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: Icon(Icons.error_outline),
            ),
            Expanded(child: Text(error)),
            Padding(
              padding: const EdgeInsets.only(left: 8.0),
              child: IconButton(
                icon: Icon(Icons.close),
                onPressed: () {
                  setState(() {
                    error = null;
                  });
                },
              ),
            ),
          ],
        ),
      );
    }
    return Container(
      color: Colors.amberAccent,
      width: double.infinity,
      padding: EdgeInsets.all(8.0),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
          body: AnnotatedRegion<SystemUiOverlayStyle>(
            value: SystemUiOverlayStyle.light,
            child: GestureDetector(
              onTap: () => FocusScope.of(context).unfocus(),
              child: Stack(
                children: <Widget>[
                  SizedBox(height: 20),
                  showAlert(),
                  SizedBox(height: 20),
                  Container(
                    height: double.infinity,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Color(0xFF73AEF5),
                          Color(0xFF61A4F1),
                          Color(0xFF478DE0),
                          Color(0xFF398AE5),
                        ],
                        stops: [0.1, 0.4, 0.7, 0.9],
                      ),
                    ),
                    child: SingleChildScrollView(
                      physics: AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.symmetric(
                        horizontal: 40,
                        vertical: 75,
                      ),
                      child: Form(
                        key: _signupformKey,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Align(
                              alignment: Alignment.topLeft,
                              child: Text(
                                'CREATE ACCOUNT',
                                style: GoogleFonts.openSans(
                                    fontSize: 45,
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600),
                              ),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                /*Text(
                              'First Name',
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            ),*/
                                SizedBox(
                                  height: 10,
                                ),
                                Container(
                                    alignment: Alignment.centerLeft,
                                    decoration: BoxDecoration(
                                        color: Color(0xFF6CA8F1),
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.black12,
                                              blurRadius: 6,
                                              offset: Offset(0, 2))
                                        ]),
                                    height: 60,
                                    child: TextFormField(
                                      controller: namecon,
                                      validator: FirstNameValidator.validate,
                                      // (value) {
                                      //   if (value.isEmpty) {
                                      //     return '        *Please Enter Name';
                                      //   }
                                      //   return null;
                                      // },
                                      keyboardType: TextInputType.emailAddress,
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          contentPadding:
                                              EdgeInsets.only(top: 14),
                                          prefixIcon: Icon(Icons.account_circle,
                                              color: Colors.white),
                                          hintText: "First Name",
                                          hintStyle: kHintTextStyle),
                                    ))
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 10,
                                ),
                                Container(
                                    alignment: Alignment.centerLeft,
                                    decoration: BoxDecoration(
                                        color: Color(0xFF6CA8F1),
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.black12,
                                              blurRadius: 6,
                                              offset: Offset(0, 2))
                                        ]),
                                    height: 60,
                                    child: TextFormField(
                                      controller: lastnamecon,
                                      validator: LastNameValidator.validate,
                                      // (value) {
                                      //   if (value.isEmpty) {
                                      //     return "       *Please Enter Last name";
                                      //   }
                                      //   return null;
                                      // },
                                      keyboardType: TextInputType.emailAddress,
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          contentPadding:
                                              EdgeInsets.only(top: 14),
                                          prefixIcon: Icon(Icons.account_circle,
                                              color: Colors.white),
                                          hintText: "Last name",
                                          hintStyle: kHintTextStyle),
                                    ))
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 10,
                                ),
                                Container(
                                    alignment: Alignment.centerLeft,
                                    decoration: BoxDecoration(
                                        color: Color(0xFF6CA8F1),
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.black12,
                                              blurRadius: 6,
                                              offset: Offset(0, 2))
                                        ]),
                                    height: 60,
                                    child: TextFormField(
                                      controller: signUpEmailcon,
                                      validator: EmailValidator.validate,
                                      // (value) {
                                      //   return RegExp(
                                      //               r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                      //           .hasMatch(value)
                                      //       ? null
                                      //       : "         * Enter a valid Email";
                                      // },
                                      keyboardType: TextInputType.emailAddress,
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                      decoration: InputDecoration(
                                          border: InputBorder.none,
                                          contentPadding:
                                              EdgeInsets.only(top: 14),
                                          prefixIcon: Icon(Icons.mail,
                                              color: Colors.white),
                                          hintText: "Email",
                                          hintStyle: kHintTextStyle),
                                    ))
                              ],
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(
                                  height: 10,
                                ),
                                Container(
                                    alignment: Alignment.centerLeft,
                                    decoration: BoxDecoration(
                                        color: Color(0xFF6CA8F1),
                                        borderRadius: BorderRadius.circular(10),
                                        boxShadow: [
                                          BoxShadow(
                                              color: Colors.black12,
                                              blurRadius: 6,
                                              offset: Offset(0, 2))
                                        ]),
                                    height: 60,
                                    child: TextFormField(
                                      controller: signUpPasscon,
                                      validator: PasswordValidator.validate,
                                      obscureText: isHiddenPassword,
                                      style: TextStyle(
                                        color: Colors.white,
                                      ),
                                      decoration: InputDecoration(
                                        border: InputBorder.none,
                                        contentPadding:
                                            EdgeInsets.only(top: 14),
                                        prefixIcon: Icon(Icons.lock,
                                            color: Colors.white),
                                        hintText: "Password",
                                        hintStyle: kHintTextStyle,
                                        suffixIcon: InkWell(
                                          onTap: _togglePasswordView,
                                          child: Icon(
                                            isHiddenPassword
                                                ? Icons.visibility
                                                : Icons.visibility_off,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ))
                              ],
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            Container(
                                padding: EdgeInsets.symmetric(vertical: 25),
                                width: double.infinity,
                                child: ElevatedButton(
                                  child: Text(
                                    'SIGN UP',
                                    style: GoogleFonts.openSans(
                                      color: Color(0xFF527DAA),
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                      letterSpacing: 1.5,
                                    ),
                                  ),
                                  onPressed: () async {
                                    if (_signupformKey.currentState.validate()) {
                                      // print("Pressed");
                                      setState(() {
                                        signupEmail = signUpEmailcon.text;
                                        signupPass = signUpPasscon.text;
                                        confirmPass = confirmPasscon.text;
                                        firstName = namecon.text;
                                        lastName = lastnamecon.text;

                                        print('SignUpEmail: $signupEmail');
                                        print('SignUpPass: $signupPass');
                                        print('ConfirmPass: $confirmPass');
                                        print('First Name: $firstName');
                                        print('Last Name: $lastName');
                                      });
                                      dynamic result = await _auth.register(firstName, lastName, signupEmail, signupPass);
                                      if (result == null) {
                                        result = await _auth.returnError();
                                        setState(() {
                                          error = result;
                                        });
                                      }
                                      print("error: " + error);
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                      padding: EdgeInsets.all(15),
                                      primary: Colors.white,
                                      shape: RoundedRectangleBorder(
                                          borderRadius:
                                              BorderRadius.circular(30))),
                                )),
                            GestureDetector(
                              onTap: () {
                                Navigator.pushReplacement(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) => SignIn()));
                                print('Sign up pressed');
                              },
                              child: RichText(
                                  text: TextSpan(children: [
                                TextSpan(
                                    text: 'Already have an Account?',
                                    style: kLabelStyle),
                                TextSpan(text: ' Sign in', style: kLabelStyle)
                              ])),
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        );
  }
}

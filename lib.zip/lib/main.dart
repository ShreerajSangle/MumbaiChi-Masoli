import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:mumbaichimasoli/config/config.dart';
import 'package:mumbaichimasoli/models/user.dart';
import 'package:mumbaichimasoli/screen/splash_screen.dart';
// import 'package:mumbaichimasoli/screen/wrapper.dart';
import 'package:mumbaichimasoli/services/auth.dart';
import 'package:provider/provider.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setEnabledSystemUIOverlays([]);
  await Firebase.initializeApp();
  ConstantVariable.auth = FirebaseAuth.instance;
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    // ignore: missing_required_param
    return StreamProvider<AppUser>.value(
      value: AuthService().user,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'MUMBAI CHI MASOLI',
        theme: ThemeData(),
        home: SplashScreenWidget(),
      ),
    ); 
  }
}

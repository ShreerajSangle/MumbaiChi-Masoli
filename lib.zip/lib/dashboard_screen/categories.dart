import 'package:flutter/material.dart';

class CategoryList extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold
      (
        appBar: AppBar
          (
          title: Text('Category List'),
          backgroundColor: Colors.blueAccent,
        ),
        body: ListView(children: <Widget>[
          Center(
              child: Text(
                'Category-Chart',
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold, color: Colors.blueAccent),
              )),
          DataTable(
              columns: const <DataColumn>[
                DataColumn(
                  label: Text(
                    'No',
                    style: TextStyle(fontStyle: FontStyle.normal),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Name',
                    style: TextStyle(fontStyle: FontStyle.normal),
                  ),
                ),
                DataColumn(
                  label: Text(
                    'Category',
                    style: TextStyle(fontStyle: FontStyle.normal),
                  ),
                ),
              ],
              rows: const <DataRow>[
                DataRow(
                  cells: <DataCell>[
                    DataCell(Text('1')),
                    DataCell(Text('a')),
                    DataCell(Text('b')),
                  ],
                ),
                DataRow(
                  cells: <DataCell>[
                    DataCell(Text('2')),
                    DataCell(Text('c')),
                    DataCell(Text('d')),
                  ],
                ),
                DataRow(
                  cells: <DataCell>[
                    DataCell(Text('3')),
                    DataCell(Text('e')),
                    DataCell(Text('f')),
                  ],
                ),
              ]
          ),
        ],
        )
    );
  }
}


Future navigateToCategoryListPage(context) async {
  Navigator.push(context, MaterialPageRoute(builder: (context) => CategoryList()));
}

import 'package:flutter/material.dart';

class Users extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    return Scaffold
      (
      appBar: AppBar
        (
          title: Text('User List'),
          backgroundColor: Colors.blueAccent,
        ),
        body: ListView(children: <Widget>[
          Center(
              child: Text(
                'Users-Chart',
                style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold, color: Colors.blueAccent),
              )),
          DataTable(
            columns: const <DataColumn>[
          DataColumn(
            label: Text(
                'FirstName',
                style: TextStyle(fontStyle: FontStyle.normal),
            ),
          ),
          DataColumn(
            label: Text(
                'LastName',
                style: TextStyle(fontStyle: FontStyle.normal),
            ),
          ),
          DataColumn(
            label: Text(
              'Email',
              style: TextStyle(fontStyle: FontStyle.normal),
            ),
          ),
        ],
        rows: const <DataRow>[
          DataRow(
          cells: <DataCell>[
            DataCell(Text('Ravi')),
            DataCell(Text('kumar')),
            DataCell(Text('ravi@gmail.com')),
          ],
         ),
          DataRow(
          cells: <DataCell>[
            DataCell(Text('Jane')),
            DataCell(Text('William')),
            DataCell(Text('jane@gmail.com')),
            ],
          ),
          DataRow(
          cells: <DataCell>[
            DataCell(Text('William')),
            DataCell(Text('Jane')),
            DataCell(Text('willam@gmail.com')),
            ],
          ),
    ]
        ),
    ],
    )
    );
  }
}

  Future navigateToUserPage(context) async {
    Navigator.push(context, MaterialPageRoute(builder: (context) => Users()));
  }

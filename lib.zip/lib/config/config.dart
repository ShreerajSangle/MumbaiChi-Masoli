
import 'package:firebase_auth/firebase_auth.dart';

class ConstantVariable {

  static FirebaseAuth auth;
  static String aid;

}


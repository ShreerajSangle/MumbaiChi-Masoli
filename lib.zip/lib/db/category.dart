import 'package:uuid/uuid.dart';

class CategoryService{
  void createCategory(String text) {
    var id = Uuid();
    String categoryId = id.v1();
  }

}

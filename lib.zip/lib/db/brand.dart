import 'package:uuid/uuid.dart';

class BrandService{
  void createBrand(String text) {
    var id = Uuid();
    String brandId = id.v1();
  }

}
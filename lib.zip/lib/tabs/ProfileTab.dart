import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/screen/OrderHistory.dart';
import 'package:mumbaichimasoli/services/auth.dart';
// import 'package:mumbaichimasoli/widgets/topBar.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/screen/ShippingAdd.dart';
import 'package:mumbaichimasoli/screen/SignIn.dart';

class ProfileTb extends StatefulWidget {
  @override
  _ProfileTbState createState() => _ProfileTbState();
}

class _ProfileTbState extends State<ProfileTb> {
  final DatabaseService _databaseService = DatabaseService();

  Future<void> editFieldsDailog(BuildContext context) async {
    final TextEditingController fnameController = TextEditingController();
    final TextEditingController lnameController = TextEditingController();
    return await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(12.0))),
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 20),
            content: Stack(
              children: <Widget>[
                Form(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: <Widget>[
                      Text(
                        "ENTER NEW DETAILS",
                        style: boldHead,
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: fnameController,
                          decoration: InputDecoration(hintText: "First Name"),
                        ),
                      ),
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: TextFormField(
                          controller: lnameController,
                          decoration: InputDecoration(hintText: "Last Name"),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                  child: Text("CANCEL")),
              TextButton(
                  onPressed: () {
                    _databaseService.updateUserName(
                        fnameController.text, lnameController.text);
                    Navigator.pop(context);
                  },
                  child: Text("SUBMIT"))
            ],
          );
        });
  }

  Size screenSize() {
    return MediaQuery.of(context).size;
  }

  final AuthService _auth = AuthService();
  final CollectionReference userCollection =
      FirebaseFirestore.instance.collection('users');
  // String uid = "${_auth.getUserId()}";

  @override
  Widget build(BuildContext context) {
    //  String uid = _auth.getUserId();

    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(80),
        child: AppBar(
            elevation: 0.5,
            title: Padding(
              padding: const EdgeInsets.only(
                  top: 55, left: 24, right: 24.0, bottom: 24.0),
              child: Text(
                "Profile",
                style: GoogleFonts.poppins(
                    color: Colors.black,
                    fontSize: 24,
                    fontWeight: FontWeight.bold),
              ),
            ),
            backgroundColor: Colors.white),
      ),
      body: SingleChildScrollView(
        // physics: NeverScrollableScrollPhysics,
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 50, horizontal: 15),
              child: StreamBuilder(
                stream: userCollection.doc(_auth.getUserId()).snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Scaffold(
                      body: Center(
                        child: Text("Error: ${snapshot.error}"),
                      ),
                    );
                  }
                  if (snapshot.connectionState == ConnectionState.active) {
                    Map _currentuser = snapshot.data.data();

                    return Container(
                        child: Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 10, horizontal: 10),
                      child: Stack(
                        children: [
                          Container(
                            child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        "${_currentuser['fname']}",
                                        style: regHead,
                                      ),
                                      SizedBox(
                                        width: 6,
                                      ),
                                      Text(
                                        "${_currentuser['lname']}",
                                        style: regHead,
                                      ),
                                      SizedBox(
                                        width: 10,
                                      ),
                                      InkWell(
                                        onTap: () async {
                                          await editFieldsDailog(context);
                                        },
                                        child: Icon(
                                          Icons.edit,
                                          size: 20,
                                          color: Colors.grey,
                                        ),
                                      )
                                    ],
                                  ),
                                  Row(
                                    children: [
                                      Text(
                                        "${_currentuser['email']}",
                                      ),
                                    ],
                                  ),
                                  SizedBox(
                                    height: 50,
                                  ),
                                  // TextButton(
                                  //   onPressed: () {},
                                  //   child: Row(
                                  //     children: [
                                  //       Expanded(
                                  //           child: Text(
                                  //         "Your orders",
                                  //         style: TextStyle(color: Colors.black),
                                  //       )),
                                  //       Icon(Icons.arrow_forward_ios)
                                  //     ],
                                  //   ),
                                  //   style: TextButton.styleFrom(
                                  //       padding: EdgeInsets.all(15),
                                  //       shape: RoundedRectangleBorder(
                                  //           borderRadius:
                                  //               BorderRadius.circular(18)),
                                  //       backgroundColor: Colors.blue[50]),
                                  // ),
                                  // SizedBox(
                                  //   height: 10,
                                  // ),
                                  TextButton(
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) =>
                                                  ShippingAdd()));
                                    },
                                    child: Row(
                                      children: [
                                        Expanded(
                                            child: Text(
                                          "Shipping Address",
                                          style: TextStyle(color: Colors.black),
                                        )),
                                        Icon(Icons.arrow_forward_ios)
                                      ],
                                    ),
                                    style: TextButton.styleFrom(
                                        padding: EdgeInsets.all(15),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(18)),
                                        backgroundColor: Colors.blue[50]),
                                  ),
                                  // SizedBox(
                                  //   height: 10,
                                  // ),
                                  // TextButton(
                                  //   onPressed: () {},
                                  //   child: Row(
                                  //     children: [
                                  //       Expanded(
                                  //           child: Text(
                                  //         "Feedback",
                                  //         style: TextStyle(color: Colors.black),
                                  //       )),
                                  //       Icon(Icons.arrow_forward_ios)
                                  //     ],
                                  //   ),
                                  //   style: TextButton.styleFrom(
                                  //       padding: EdgeInsets.all(15),
                                  //       shape: RoundedRectangleBorder(
                                  //           borderRadius:
                                  //               BorderRadius.circular(18)),
                                  //       backgroundColor: Colors.blue[50]),
                                  // ),
                                  SizedBox(height: 10),
                                  TextButton(
                                    onPressed: () async {
                                      Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => YourOrders(
                                                  userId: _auth.getUserId())));
                                    },
                                    child: Row(
                                      children: [
                                        Icon(Icons.insert_emoticon_sharp),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Expanded(
                                            child: Text(
                                          "Your Orders",
                                          style: TextStyle(color: Colors.black),
                                        )),
                                        Icon(Icons.arrow_forward_ios)
                                      ],
                                    ),
                                    style: TextButton.styleFrom(
                                        padding: EdgeInsets.all(15),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(18)),
                                        backgroundColor: Colors.blue[50]),
                                  ),
                                  SizedBox(height: 10),
                                  TextButton(
                                    onPressed: () async {
                                      await _auth.signOut();
                                      Navigator.pushReplacement(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => SignIn()));
                                    },
                                    child: Row(
                                      children: [
                                        Icon(Icons.logout),
                                        SizedBox(
                                          width: 5,
                                        ),
                                        Expanded(
                                            child: Text(
                                          "LOG OUT",
                                          style: TextStyle(color: Colors.black),
                                        )),
                                        Icon(Icons.arrow_forward_ios)
                                      ],
                                    ),
                                    style: TextButton.styleFrom(
                                        padding: EdgeInsets.all(15),
                                        shape: RoundedRectangleBorder(
                                            borderRadius:
                                                BorderRadius.circular(18)),
                                        backgroundColor: Colors.blue[50]),
                                  ),
                                ]),
                          ),
                        ],
                      ),
                    ));
                  }

                  return Center(
                    child: CircularProgressIndicator(),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

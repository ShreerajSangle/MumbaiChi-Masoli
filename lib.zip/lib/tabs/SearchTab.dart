import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/screen/detailProdAdmin.dart';
// import 'package:mumbaichimasoli/services/firebaseServices.dart';
import 'package:mumbaichimasoli/services/database.dart';
import 'package:mumbaichimasoli/widgets/SearchInput.dart';
import 'package:mumbaichimasoli/widgets/productCard.dart';
import '../constants.dart';

class SearchTb extends StatefulWidget {
  @override
  _SearchTbState createState() => _SearchTbState();
}

class _SearchTbState extends State<SearchTb> {
  String _searchString = "";

  DatabaseService _databaseService = DatabaseService();
  // FirebaseServices _firebaseServices = FirebaseServices();
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Stack(
        children: [
          if (_searchString.isEmpty)
            Container(
                alignment: Alignment.center,
                child: Text(
                  "Search Results",
                  style: regHead,
                ))
          else
            Padding(
              padding: EdgeInsets.only(top: 20),
              child: FutureBuilder<QuerySnapshot>(
                future: _databaseService.productsReference
                    .orderBy("searchString")
                    .startAt([_searchString]).endAt(
                        ["$_searchString\uf8ff"]).get(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Scaffold(
                      body: Center(
                        child: Text("Error: ${snapshot.error}"),
                      ),
                    );
                  }

                  if (snapshot.connectionState == ConnectionState.done) {
                    return ListView(
                        padding: EdgeInsets.only(top: 80.0, bottom: 20.0),
                        children: snapshot.data.docs.map((document) {
                          return ProductCard(
                            title: document["name"],
                            imageUrl: document['images'][0],
                            price: "\₹${document["price"]}",
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => DetailProdAdmin(
                                            productId: document.id,
                                          )));
                            },
                          );
                        }).toList());
                  }

                  return Scaffold(
                    body: Center(
                      child: CircularProgressIndicator(),
                    ),
                  );
                },
              ),
            ),
          SearchInput(
            keyboardType: TextInputType.name,
            hintText: "Search..",
            onSubmitted: (value) {
              setState(() {
                _searchString = value.toLowerCase();
              });
            },
          ),
        ],
      ),
    );
  }
}

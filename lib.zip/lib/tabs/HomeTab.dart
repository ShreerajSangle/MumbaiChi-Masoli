import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:mumbaichimasoli/constants.dart';
import 'package:mumbaichimasoli/screen/detailProd.dart';

import 'package:mumbaichimasoli/widgets/productCard.dart';
import 'package:mumbaichimasoli/widgets/topBar.dart';

class HomeTb extends StatelessWidget {
  final CollectionReference _productsRefrence =
      FirebaseFirestore.instance.collection('products');
  @override
  Widget build(BuildContext context) {
    Size screenSize() {
      return MediaQuery.of(context).size;
    }

    return Container(
      child: Stack(
        children: <Widget>[
          FutureBuilder<QuerySnapshot>(
            future: _productsRefrence.get(),
            builder: (context, snapshot) {
              if (snapshot.hasError) {
                return Scaffold(
                  body: Center(
                    child: Text("Error: ${snapshot.error}"),
                  ),
                );
              }

              if (snapshot.connectionState == ConnectionState.done) {
                return ListView(
                    padding: EdgeInsets.only(top: 80.0, bottom: 20.0),
                    children: snapshot.data.docs.map((document) {
                      return ProductCard(
                        title: document["name"],
                        imageUrl: document['images'][0],
                        price: "\₹${document["price"]}",
                        onPressed: () {
                          try {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        DetailProd(
                                          productId: document.id,
                                        )));
                          }catch(e){
                            print(e.toString());
                          }
                        },
                      );
                    }).toList());
              }

              return Scaffold(
                body: Center(
                  child: CircularProgressIndicator(),
                ),
              );
            },
          ),
          TopBar(
            title: "Mumbai chi Masoli",
          ),
        ],
      ),
    );
  }
}
